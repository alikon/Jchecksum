

CREATE TABLE `ltqri_slicomments` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `raw` text NOT NULL,
  `text` text NOT NULL,
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `article_id` int(10) unsigned NOT NULL,
  `rating` int(11) NOT NULL default '0',
  `status` smallint(6) default '1',
  PRIMARY KEY  (`id`),
  KEY `idx_article_id` (`article_id`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=622 DEFAULT CHARSET=utf8;

INSERT INTO ltqri_slicomments VALUES("9","0","Patric","tjipp@gmail.com","And where the feck is the Ajax Captcha ?","And where the feck is the Ajax Captcha ?","2012-03-16 10:51:16","16","0","1");
INSERT INTO ltqri_slicomments VALUES("10","0","leen","leen@leen.com","captcha?","captcha?","2012-03-16 18:51:41","16","0","1");
INSERT INTO ltqri_slicomments VALUES("25","0","Stupids","lol@lol.lol","AT REGISTRATION PAGE OBVIOUSLY?","AT REGISTRATION PAGE OBVIOUSLY?","2012-03-22 01:38:32","16","0","1");
INSERT INTO ltqri_slicomments VALUES("27","0","Arthur Hoffmann","shibadom@sbg.at","chapter","chapter","2012-03-24 02:03:34","16","0","1");
INSERT INTO ltqri_slicomments VALUES("28","0","Arthur Hoffmann","office@dk2.at","Get i the capter per mail ?","Get i the capter per mail ?","2012-03-24 02:05:44","16","0","1");
INSERT INTO ltqri_slicomments VALUES("40","15716","","","where are set up instructions?","where are set up instructions?","2012-04-10 01:08:32","16","0","1");
INSERT INTO ltqri_slicomments VALUES("115","0","Sumeet","jimenezcalvo@ucr.ac.cr","09/19/2010 at 10:14 am</a>Thanks for the feedback, I look fowrard to the update. Other than the issue I mentioned your plugin works really well. Before using your plugin I was getting from 3-5 spammy registrations a day and was manually checking against the Stop Forum Spam Db. Your plugin eliminated all of those completely, and since I disabled the plugin to check with the registration issues, spam registrations have started again.I\'ll clear the cache and let you know how I get on, thanks","09/19/2010 at 10:14 am&lt;/a&gt;Thanks for the feedback, I look fowrard to the update. Other than the issue I mentioned your plugin works really well. Before using your plugin I was getting from 3-5 spammy registrations a day and was manually checking against the Stop Forum Spam Db. Your plugin eliminated all of those completely, and since I disabled the plugin to check with the registration issues, spam registrations have started again.I&#039;ll clear the cache and let you know how I get on, thanks","2012-04-13 03:21:22","14","0","1");
INSERT INTO ltqri_slicomments VALUES("134","0","Chermae","asferet@vela.filg.uj.edu.pl","Great plug-in.  Works right out of the box (which I love).  One small issue: I can\'t get the tweet/retweet button out of the top left of the setcion header.  I excluded all categories in the setcion but it still shows up.","Great plug-in. <img src=\"/.\" alt=\"\" title=\"\" class=\"emoticon\" /> Works right out of the box (which I love). <img src=\"/.\" alt=\"\" title=\"\" class=\"emoticon\" /> One small issue: I can&#039;t get the tweet/retweet button out of the top left of the setcion header. <img src=\"/.\" alt=\"\" title=\"\" class=\"emoticon\" /> I excluded all categories in the setcion but it still shows up.","2012-04-13 06:54:26","1","0","1");
INSERT INTO ltqri_slicomments VALUES("509","0","Cooper","dirtbill@yahoo.com","How would you like the money? <a href=\" http://www.smcmba.com \">zoloft mg</a>  a D in the first position of the codes for UT/PC in Additional Message (526-FQ)
 ","How would you like the money? &lt;a href=&quot; http://www.smcmba.com &quot;&gt;zoloft mg&lt;/a&gt;  a D in the first position of the codes for UT/PC in Additional Message (526-FQ)<br />
 ","2012-10-22 17:34:50","11","0","-1");
INSERT INTO ltqri_slicomments VALUES("510","0","poincinge","g70@gmail.com","<a href=\"http://www.monclerjacketsuk.eu\">moncler outlet</a> Kz95aqZp42 <a href=\"http://www.monclerjacketsuk.eu\">moncler uk</a> Wz19zzOa73 <a href=\"http://www.monclerjacketsuk.eu\">moncler outlet</a> Hp52skNj60 <a href=\"http://www.monclerjacketsuk.eu\">http://www.monclerjacketsuk.eu</a>  2ax","&lt;a href=&quot;http://www.monclerjacketsuk.eu&quot;&gt;moncler outlet&lt;/a&gt; Kz95aqZp42 &lt;a href=&quot;http://www.monclerjacketsuk.eu&quot;&gt;moncler uk&lt;/a&gt; Wz19zzOa73 &lt;a href=&quot;http://www.monclerjacketsuk.eu&quot;&gt;moncler outlet&lt;/a&gt; Hp52skNj60 &lt;a href=&quot;http://www.monclerjacketsuk.eu&quot;&gt;http://www.monclerjacketsuk.eu&lt;/a&gt;  2ax","2012-10-22 21:03:37","28","0","-1");
INSERT INTO ltqri_slicomments VALUES("511","0","poincinge","s21@gmail.com","<a href=\"http://www.monclerjacketsuk.eu\">moncler jackets</a> Pc25qvPl18 <a href=\"http://www.monclerjacketsuk.eu\">moncler jackets</a> Lp51uiRz03 <a href=\"http://www.monclerjacketsuk.eu\">moncler jackets</a> Om78guZv21 <a href=\"http://www.monclerjacketsuk.eu\">http://www.monclerjacketsuk.eu</a>  2ax","&lt;a href=&quot;http://www.monclerjacketsuk.eu&quot;&gt;moncler jackets&lt;/a&gt; Pc25qvPl18 &lt;a href=&quot;http://www.monclerjacketsuk.eu&quot;&gt;moncler jackets&lt;/a&gt; Lp51uiRz03 &lt;a href=&quot;http://www.monclerjacketsuk.eu&quot;&gt;moncler jackets&lt;/a&gt; Om78guZv21 &lt;a href=&quot;http://www.monclerjacketsuk.eu&quot;&gt;http://www.monclerjacketsuk.eu&lt;/a&gt;  2ax","2012-10-22 21:03:37","24","0","-1");
INSERT INTO ltqri_slicomments VALUES("512","0","poincinge","u16@gmail.com","<a href=\"http://www.monclerjacketsuk.eu\">moncler uk</a> Wt43tiQp54 <a href=\"http://www.monclerjacketsuk.eu\">moncler outlet</a> Nf32soXp03 <a href=\"http://www.monclerjacketsuk.eu\">moncler jackets</a> Hs47wqWs63 <a href=\"http://www.monclerjacketsuk.eu\">http://www.monclerjacketsuk.eu</a>  2ax","&lt;a href=&quot;http://www.monclerjacketsuk.eu&quot;&gt;moncler uk&lt;/a&gt; Wt43tiQp54 &lt;a href=&quot;http://www.monclerjacketsuk.eu&quot;&gt;moncler outlet&lt;/a&gt; Nf32soXp03 &lt;a href=&quot;http://www.monclerjacketsuk.eu&quot;&gt;moncler jackets&lt;/a&gt; Hs47wqWs63 &lt;a href=&quot;http://www.monclerjacketsuk.eu&quot;&gt;http://www.monclerjacketsuk.eu&lt;/a&gt;  2ax","2012-10-22 21:17:07","25","0","-1");
INSERT INTO ltqri_slicomments VALUES("513","0","Isaiah","eblanned@yahoo.com","How many are there in a book? <a href=\" http://www.eminpasha.com \">duloxetine zoloft</a>  applies. If the prior approval/authorization number entered in field 12 applies to all
 ","How many are there in a book? &lt;a href=&quot; http://www.eminpasha.com &quot;&gt;duloxetine zoloft&lt;/a&gt;  applies. If the prior approval/authorization number entered in field 12 applies to all<br />
 ","2012-10-22 23:14:45","11","0","-1");
INSERT INTO ltqri_slicomments VALUES("514","0","foreiyxtw","kvsgwi@cuxaxg.com","U7MY2G  <a href=\"http://aewabegcfzxs.com/\">aewabegcfzxs</a>, [url=http://ufcwuuhkbgqm.com/]ufcwuuhkbgqm[/url], [link=http://njmzsqnymuyv.com/]njmzsqnymuyv[/link], http://qrlaizsohlbt.com/","U7MY2G  &lt;a href=&quot;http://aewabegcfzxs.com/&quot;&gt;aewabegcfzxs&lt;/a&gt;, ufcwuuhkbgqm, njmzsqnymuyv, http://qrlaizsohlbt.com/","2012-10-23 14:08:32","31","0","-1");
INSERT INTO ltqri_slicomments VALUES("515","0","pqmtoukxvq","wxgvti@sruldc.com","TKJi3F  <a href=\"http://vacfjmjgtrpw.com/\">vacfjmjgtrpw</a>, [url=http://yuxjvrssalnv.com/]yuxjvrssalnv[/url], [link=http://cfgoamfgzvmm.com/]cfgoamfgzvmm[/link], http://geqxofuiysqg.com/","TKJi3F  &lt;a href=&quot;http://vacfjmjgtrpw.com/&quot;&gt;vacfjmjgtrpw&lt;/a&gt;, yuxjvrssalnv, cfgoamfgzvmm, http://geqxofuiysqg.com/","2012-10-23 16:57:55","24","0","-1");
INSERT INTO ltqri_slicomments VALUES("516","0","Marybristatte","sy.ngefn3n@gmail.com
","Way before there is<a href=\"http://www.coachsoutletstoresales.com/\">coachsoutletstoresales.com</a>
 a Phoebe Philo,the name sleepy brand http://www.coachhandbagsonlineshops.com/
there isthat wassayinghttp://www.coachhandbagsonlineshops.com
  a great deal morethere is an identity there was clearlyhttp://www.coachhandbagfactorys.com
","Way before there is&lt;a href=&quot;http://www.coachsoutletstoresales.com/&quot;&gt;coachsoutletstoresales.com&lt;/a&gt;<br />
 a Phoebe Philo,the name sleepy brand http://www.coachhandbagsonlineshops.com/<br />
there isthat wassayinghttp://www.coachhandbagsonlineshops.com<br />
  a great deal morethere is an identity there was clearlyhttp://www.coachhandbagfactorys.com<br />
","2012-10-23 20:46:05","29","0","-1");
INSERT INTO ltqri_slicomments VALUES("517","0","wjpiclnd","mlsadk@wohzlo.com","ANlSd0  <a href=\"http://ouzfyozkpdge.com/\">ouzfyozkpdge</a>, [url=http://dxgrkhevuwxo.com/]dxgrkhevuwxo[/url], [link=http://tubdqruzwxis.com/]tubdqruzwxis[/link], http://opvpcsvimtkf.com/","ANlSd0  &lt;a href=&quot;http://ouzfyozkpdge.com/&quot;&gt;ouzfyozkpdge&lt;/a&gt;, dxgrkhevuwxo, tubdqruzwxis, http://opvpcsvimtkf.com/","2012-10-23 23:07:26","15","0","-1");
INSERT INTO ltqri_slicomments VALUES("518","0","dtsscjnfd","qxxtct@jeaugv.com","SldMe4  <a href=\"http://lqvsbqlfxdzp.com/\">lqvsbqlfxdzp</a>, [url=http://dycykmbtkqfd.com/]dycykmbtkqfd[/url], [link=http://rjefckzxgmij.com/]rjefckzxgmij[/link], http://deartptkthpe.com/","SldMe4  &lt;a href=&quot;http://lqvsbqlfxdzp.com/&quot;&gt;lqvsbqlfxdzp&lt;/a&gt;, dycykmbtkqfd, rjefckzxgmij, http://deartptkthpe.com/","2012-10-24 07:31:05","14","0","-1");
INSERT INTO ltqri_slicomments VALUES("519","0","Kasiretz","kasiretz@pio21.pl","I\'d like to verbalize hello to the forum - I solicitous skim the supplemental forum so far and things being what they are I\'ll appraiser to settle something. Nicest Regards","I&#039;d like to verbalize hello to the forum - I solicitous skim the supplemental forum so far and things being what they are I&#039;ll appraiser to settle something. Nicest Regards","2012-10-24 17:02:29","26","0","-2");
INSERT INTO ltqri_slicomments VALUES("520","0","Snisppsymnnal","ntfytd4k6@gmail.com","xcwco 
<a href=\"http://www.sacllongchampsac2012.com/\"><b>sacllongchampsac2012.com/</b></a> 
fcfme 
<a href=\"http://www.chaussuresslouboutinpaschere.net/\"><b>chaussuresslouboutinpaschere.net/</b></a> 
bfdch 
<a href=\"http://www.saclouisvuittonpascher-fra.net/\"><b>saclouisvuittonpascher-fra.net/</b></a> 
rlglf 
<a href=\"http://www.sacllongchampsac2012.com/\"><b>http://www.sacllongchampsac2012.com/</b></a> 
halpc 
<a href=\"http://www.chaussuresslouboutinpaschere.net/\"><b>http://www.chaussur","xcwco <br />
&lt;a href=&quot;http://www.sacllongchampsac2012.com/&quot;&gt;&lt;b&gt;sacllongchampsac2012.com/&lt;/b&gt;&lt;/a&gt; <br />
fcfme <br />
&lt;a href=&quot;http://www.chaussuresslouboutinpaschere.net/&quot;&gt;&lt;b&gt;chaussuresslouboutinpaschere.net/&lt;/b&gt;&lt;/a&gt; <br />
bfdch <br />
&lt;a href=&quot;http://www.saclouisvuittonpascher-fra.net/&quot;&gt;&lt;b&gt;saclouisvuittonpascher-fra.net/&lt;/b&gt;&lt;/a&gt; <br />
rlglf <br />
&lt;a href=&quot;http://www.sacllongchampsac2012.com/&quot;&gt;&lt;b&gt;http://www.sacllongchampsac2012.com/&lt;/b&gt;&lt;/a&gt; <br />
halpc <br />
&lt;a href=&quot;http://www.chaussuresslouboutinpaschere.net/&quot;&gt;&lt;b&gt;http://www.chaussur","2012-10-25 04:08:52","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("521","0","Braccimmite","ucanf7o7@gmail.com","tpoub 
<a href=\"http://www.nikefreerun2012-dk.com/\"><b>nike free run</b></a> 
gotrb 
gavbj 
<a href=\"http://www.borselouisvuitton-italiane.com/\"><b>louis vuitton outlet</b></a> 
lcoqd 
phdab 
<a href=\"http://www.doudounemonclere-fra.com/\"><b>moncler pas cher</b></a> 
tvwoy 
<a href=\"http://www.borselouisvuitton-italiane.com/\"><b>http://www.borselouisvuitton-italiane.com/</b></a> 
jalru 
<a href=\"http://www.doudounemonclere-fra.com/\"><b>http://www.doudounemonclere-fra.com/</b></a> 
ft","tpoub <br />
&lt;a href=&quot;http://www.nikefreerun2012-dk.com/&quot;&gt;&lt;b&gt;nike free run&lt;/b&gt;&lt;/a&gt; <br />
gotrb <br />
gavbj <br />
&lt;a href=&quot;http://www.borselouisvuitton-italiane.com/&quot;&gt;&lt;b&gt;louis vuitton outlet&lt;/b&gt;&lt;/a&gt; <br />
lcoqd <br />
phdab <br />
&lt;a href=&quot;http://www.doudounemonclere-fra.com/&quot;&gt;&lt;b&gt;moncler pas cher&lt;/b&gt;&lt;/a&gt; <br />
tvwoy <br />
&lt;a href=&quot;http://www.borselouisvuitton-italiane.com/&quot;&gt;&lt;b&gt;http://www.borselouisvuitton-italiane.com/&lt;/b&gt;&lt;/a&gt; <br />
jalru <br />
&lt;a href=&quot;http://www.doudounemonclere-fra.com/&quot;&gt;&lt;b&gt;http://www.doudounemonclere-fra.com/&lt;/b&gt;&lt;/a&gt; <br />
ft","2012-10-25 05:55:34","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("522","0","Utircardatand","xonlfu@gmail.com","ykeht 
<a href=\"http://www.nikefreerun2012-dk.com/\"><b>nike free run</b></a> 
wdsya 
<a href=\"http://www.hogansitoufficialeui-italian.org/\"><b>hogan</b></a> 
vndgm 
<a href=\"http://www.doudounemonclere-fra.com/\"><b>doudoune moncler</b></a> 
nexjg 
<a href=\"http://www.nikefreerun2012-dk.com/\"><b>http://www.nikefreerun2012-dk.com/</b></a> 
chzuy 
<a href=\"http://www.hogansitoufficialeui-italian.org/\"><b>http://www.hogansitoufficialeui-italian.org/</b></a> hnoby aiids http://www.doudounemo","ykeht <br />
&lt;a href=&quot;http://www.nikefreerun2012-dk.com/&quot;&gt;&lt;b&gt;nike free run&lt;/b&gt;&lt;/a&gt; <br />
wdsya <br />
&lt;a href=&quot;http://www.hogansitoufficialeui-italian.org/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
vndgm <br />
&lt;a href=&quot;http://www.doudounemonclere-fra.com/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
nexjg <br />
&lt;a href=&quot;http://www.nikefreerun2012-dk.com/&quot;&gt;&lt;b&gt;http://www.nikefreerun2012-dk.com/&lt;/b&gt;&lt;/a&gt; <br />
chzuy <br />
&lt;a href=&quot;http://www.hogansitoufficialeui-italian.org/&quot;&gt;&lt;b&gt;http://www.hogansitoufficialeui-italian.org/&lt;/b&gt;&lt;/a&gt; hnoby aiids http://www.doudounemo","2012-10-25 14:12:27","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("523","0","Irina Vasilieva","kingcarrrr@aol.com","Nice post. I went through the post I found it very informative and useful. Thanks for sharing.","Nice post. I went through the post I found it very informative and useful. Thanks for sharing.","2012-10-25 16:48:15","26","0","-1");
INSERT INTO ltqri_slicomments VALUES("524","0","Lily","coco888@msn.com","I\'d like to pay this in, please <a href=\" http://stasisfield.com \">generic viagra no prescription online</a>  a central role in adherence counseling.
 ","I&#039;d like to pay this in, please &lt;a href=&quot; http://stasisfield.com &quot;&gt;generic viagra no prescription online&lt;/a&gt;  a central role in adherence counseling.<br />
 ","2012-10-25 20:48:00","11","0","-1");
INSERT INTO ltqri_slicomments VALUES("525","0","XRumerTest","twmqc1c8@gmail.com","spgaq 
<a href=\"http://www.abercrombiepaschert.com/\"><b>abercrombie</b></a> 
koinp 
<a href=\"http://www.doudounemonclerb.com/\"><b>moncler</b></a> 
ivsbb 
<a href=\"http://www.hogansitoufficialeu-italiian.org/\"><b>hogan outlet</b></a> 
xfnfy 
<a href=\"http://www.abercrombiepaschert.com/\"><b>http://www.abercrombiepaschert.com/</b></a> 
vlaev 
<a href=\"http://www.doudounemonclerb.com/\"><b>http://www.doudounemonclerb.com/</b></a> vvuyd 
 
http://www.hogansitoufficialeu-italiian.org/","spgaq <br />
&lt;a href=&quot;http://www.abercrombiepaschert.com/&quot;&gt;&lt;b&gt;abercrombie&lt;/b&gt;&lt;/a&gt; <br />
koinp <br />
&lt;a href=&quot;http://www.doudounemonclerb.com/&quot;&gt;&lt;b&gt;moncler&lt;/b&gt;&lt;/a&gt; <br />
ivsbb <br />
&lt;a href=&quot;http://www.hogansitoufficialeu-italiian.org/&quot;&gt;&lt;b&gt;hogan outlet&lt;/b&gt;&lt;/a&gt; <br />
xfnfy <br />
&lt;a href=&quot;http://www.abercrombiepaschert.com/&quot;&gt;&lt;b&gt;http://www.abercrombiepaschert.com/&lt;/b&gt;&lt;/a&gt; <br />
vlaev <br />
&lt;a href=&quot;http://www.doudounemonclerb.com/&quot;&gt;&lt;b&gt;http://www.doudounemonclerb.com/&lt;/b&gt;&lt;/a&gt; vvuyd <br />
 <br />
http://www.hogansitoufficialeu-italiian.org/","2012-10-26 01:23:23","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("526","0","XRumerTest","kqalp1c9@gmail.com","iqxwy 
<a href=\"http://www.saclouisvuittonpascherq.com/\"><b>sac louis vuitton</b></a> 
hgtyr 
<a href=\"http://www.doudounemonclere-fra.com/\"><b>doudoune moncler</b></a> 
usmkq 
<a href=\"http://www.borselouisvuitton-italiane.com/\"><b>louis vuitton borse</b></a> 
lnmre 
<a href=\"http://www.saclouisvuittonpascherq.com/\"><b>http://www.saclouisvuittonpascherq.com/</b></a> 
shduz 
<a href=\"http://www.doudounemonclere-fra.com/\"><b>http://www.doudounemonclere-fra.com/</b></a> qaxqr  http://www.","iqxwy <br />
&lt;a href=&quot;http://www.saclouisvuittonpascherq.com/&quot;&gt;&lt;b&gt;sac louis vuitton&lt;/b&gt;&lt;/a&gt; <br />
hgtyr <br />
&lt;a href=&quot;http://www.doudounemonclere-fra.com/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
usmkq <br />
&lt;a href=&quot;http://www.borselouisvuitton-italiane.com/&quot;&gt;&lt;b&gt;louis vuitton borse&lt;/b&gt;&lt;/a&gt; <br />
lnmre <br />
&lt;a href=&quot;http://www.saclouisvuittonpascherq.com/&quot;&gt;&lt;b&gt;http://www.saclouisvuittonpascherq.com/&lt;/b&gt;&lt;/a&gt; <br />
shduz <br />
&lt;a href=&quot;http://www.doudounemonclere-fra.com/&quot;&gt;&lt;b&gt;http://www.doudounemonclere-fra.com/&lt;/b&gt;&lt;/a&gt; qaxqr  http://www.","2012-10-26 02:38:06","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("505","0","Makeup tips","thew731@gmail.com","I heard a couple of guys talking about this in the New York subway so I looked it up online and found your page. Thanks. I thought I was right and you confirmed my thoughts. Thanks for the work you\'ve put into this. I\'d love to save this and share with my friends.","I heard a couple of guys talking about this in the New York subway so I looked it up online and found your page. Thanks. I thought I was right and you confirmed my thoughts. Thanks for the work you&#039;ve put into this. I&#039;d love to save this and share with my friends.","2012-10-20 04:21:27","26","0","1");
INSERT INTO ltqri_slicomments VALUES("527","0","DictBoigo","rporivjwoern@gmail.com","http://allbestedmeds.com/acheter-avana-france.html avanafil Erectile dysfunction is also pill of Avanafil.  subset of patients of avanafil and should Avanafil is what you.  <a href=http://allbestedmeds.com/compra-avana-italy.html>avanafil</a> The advantage of avanafil than your body actually on a stable dose one in 24 hours.  http://allbestedmeds.com/buy-avana-usa.html - buy avanafil Despite what the FDA for me since my infrequent side effects associated the way your body.  ","http://allbestedmeds.com/acheter-avana-france.html avanafil Erectile dysfunction is also pill of Avanafil.  subset of patients of avanafil and should Avanafil is what you.  &lt;a href=http://allbestedmeds.com/compra-avana-italy.html&gt;avanafil&lt;/a&gt; The advantage of avanafil than your body actually on a stable dose one in 24 hours.  http://allbestedmeds.com/buy-avana-usa.html - buy avanafil Despite what the FDA for me since my infrequent side effects associated the way your body.  ","2012-10-26 09:24:36","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("528","0","XRumerTest","vmrbm4f7@gmail.com","blyvp 
<a href=\"http://www.abercrombiepaschert.com/\"><b>abercrombie pas cher</b></a> 
gmnju 
<a href=\"http://www.doudounemonclerb.com/\"><b>doudoune moncler</b></a> 
zejka 
<a href=\"http://www.hogansitoufficialeu-italiian.org/\"><b>hogan outlet</b></a> 
lyyzz 
<a href=\"http://www.abercrombiepaschert.com/\"><b>http://www.abercrombiepaschert.com/</b></a> 
rkupp 
<a href=\"http://www.doudounemonclerb.com/\"><b>http://www.doudounemonclerb.com/</b></a> mkndk 
 
http://www.hogansitoufficialeu-it","blyvp <br />
&lt;a href=&quot;http://www.abercrombiepaschert.com/&quot;&gt;&lt;b&gt;abercrombie pas cher&lt;/b&gt;&lt;/a&gt; <br />
gmnju <br />
&lt;a href=&quot;http://www.doudounemonclerb.com/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
zejka <br />
&lt;a href=&quot;http://www.hogansitoufficialeu-italiian.org/&quot;&gt;&lt;b&gt;hogan outlet&lt;/b&gt;&lt;/a&gt; <br />
lyyzz <br />
&lt;a href=&quot;http://www.abercrombiepaschert.com/&quot;&gt;&lt;b&gt;http://www.abercrombiepaschert.com/&lt;/b&gt;&lt;/a&gt; <br />
rkupp <br />
&lt;a href=&quot;http://www.doudounemonclerb.com/&quot;&gt;&lt;b&gt;http://www.doudounemonclerb.com/&lt;/b&gt;&lt;/a&gt; mkndk <br />
 <br />
http://www.hogansitoufficialeu-it","2012-10-26 09:28:41","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("529","0","XRumerTest","wvucc3g8@gmail.com","bcmip 
<a href=\"http://www.hogansitoufficialeui-italian.org/\"><b>scarpe hogan</b></a> 
bnfgl 
<a href=\"http://www.nikefree2012-dkt.com/\"><b>nike free run</b></a> 
hlbyr 
<a href=\"http://www.itescarpehogansitoufficiale.com/\"><b>hogan outlet</b></a> 
bdczv 
<a href=\"http://www.hogansitoufficialeui-italian.org/\"><b>http://www.hogansitoufficialeui-italian.org/</b></a> 
gsnwg 
<a href=\"http://www.nikefree2012-dkt.com/\"><b>http://www.nikefree2012-dkt.com/</b></a> dguqk  http://www.itescarpeho","bcmip <br />
&lt;a href=&quot;http://www.hogansitoufficialeui-italian.org/&quot;&gt;&lt;b&gt;scarpe hogan&lt;/b&gt;&lt;/a&gt; <br />
bnfgl <br />
&lt;a href=&quot;http://www.nikefree2012-dkt.com/&quot;&gt;&lt;b&gt;nike free run&lt;/b&gt;&lt;/a&gt; <br />
hlbyr <br />
&lt;a href=&quot;http://www.itescarpehogansitoufficiale.com/&quot;&gt;&lt;b&gt;hogan outlet&lt;/b&gt;&lt;/a&gt; <br />
bdczv <br />
&lt;a href=&quot;http://www.hogansitoufficialeui-italian.org/&quot;&gt;&lt;b&gt;http://www.hogansitoufficialeui-italian.org/&lt;/b&gt;&lt;/a&gt; <br />
gsnwg <br />
&lt;a href=&quot;http://www.nikefree2012-dkt.com/&quot;&gt;&lt;b&gt;http://www.nikefree2012-dkt.com/&lt;/b&gt;&lt;/a&gt; dguqk  http://www.itescarpeho","2012-10-26 10:24:30","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("530","0","Jewweakly","duueh6o.igvh.7ep3.8v@gmail.com","<a href=http://airjodannchaussresmagainn.webnode.fr/>air jordan pas cher </a> 
r p rb v 
 
http://airjodannchaussresmagainn.webnode.fr/","&lt;a href=http://airjodannchaussresmagainn.webnode.fr/&gt;air jordan pas cher &lt;/a&gt; <br />
r p rb v <br />
 <br />
http://airjodannchaussresmagainn.webnode.fr/","2012-10-26 11:13:20","28","0","-1");
INSERT INTO ltqri_slicomments VALUES("531","0","Braccimmite","rbnfd6z1@gmail.com","vbaso 
<a href=\"http://www.nikefreerun2012-dk.com/\"><b>nike free</b></a> 
ekoql 
wqmzi 
<a href=\"http://www.borselouisvuitton-italiane.com/\"><b>louis vuitton borse</b></a> 
ypizj 
lnhml 
<a href=\"http://www.doudounemonclere-fra.com/\"><b>moncler pas cher</b></a> 
ntzzi 
<a href=\"http://www.borselouisvuitton-italiane.com/\"><b>http://www.borselouisvuitton-italiane.com/</b></a> 
oundc 
<a href=\"http://www.doudounemonclere-fra.com/\"><b>http://www.doudounemonclere-fra.com/</b></a> 
hpcii ","vbaso <br />
&lt;a href=&quot;http://www.nikefreerun2012-dk.com/&quot;&gt;&lt;b&gt;nike free&lt;/b&gt;&lt;/a&gt; <br />
ekoql <br />
wqmzi <br />
&lt;a href=&quot;http://www.borselouisvuitton-italiane.com/&quot;&gt;&lt;b&gt;louis vuitton borse&lt;/b&gt;&lt;/a&gt; <br />
ypizj <br />
lnhml <br />
&lt;a href=&quot;http://www.doudounemonclere-fra.com/&quot;&gt;&lt;b&gt;moncler pas cher&lt;/b&gt;&lt;/a&gt; <br />
ntzzi <br />
&lt;a href=&quot;http://www.borselouisvuitton-italiane.com/&quot;&gt;&lt;b&gt;http://www.borselouisvuitton-italiane.com/&lt;/b&gt;&lt;/a&gt; <br />
oundc <br />
&lt;a href=&quot;http://www.doudounemonclere-fra.com/&quot;&gt;&lt;b&gt;http://www.doudounemonclere-fra.com/&lt;/b&gt;&lt;/a&gt; <br />
hpcii <br />","2012-10-26 20:02:38","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("532","0","Nicolai","kiberrom@gmail.com","Здравствуйте.
Не могу зарегистрироваться, можно ли другим способом получить \"AContact Manager 2.5.1\" ?","Здравствуйте.<br />
Не могу зарегистрироваться, можно ли другим способом получить &quot;AContact Manager 2.5.1&quot; ?","2012-10-26 23:54:39","27","0","-2");
INSERT INTO ltqri_slicomments VALUES("533","0","Nicolai","kiberrom@gmail.com","Hello.
 I can not log in to the website. How can I get \"AContact Manager 2.5.1\"?
 Thank you.","Hello.<br />
 I can not log in to the website. How can I get &quot;AContact Manager 2.5.1&quot;?<br />
 Thank you.","2012-10-27 00:53:23","27","0","1");
INSERT INTO ltqri_slicomments VALUES("534","0","Utircardatand","oetvoe@gmail.com","zppaf 
<a href=\"http://www.nikefreerun2012-dk.com/\"><b>nike free</b></a> 
ruzzb 
<a href=\"http://www.hogansitoufficialeui-italian.org/\"><b>scarpe hogan</b></a> 
hlolk 
<a href=\"http://www.doudounemonclere-fra.com/\"><b>doudoune moncler</b></a> 
fsbcs 
<a href=\"http://www.nikefreerun2012-dk.com/\"><b>http://www.nikefreerun2012-dk.com/</b></a> 
pfqjt 
<a href=\"http://www.hogansitoufficialeui-italian.org/\"><b>http://www.hogansitoufficialeui-italian.org/</b></a> qmcob xhfxa http://www.doudoun","zppaf <br />
&lt;a href=&quot;http://www.nikefreerun2012-dk.com/&quot;&gt;&lt;b&gt;nike free&lt;/b&gt;&lt;/a&gt; <br />
ruzzb <br />
&lt;a href=&quot;http://www.hogansitoufficialeui-italian.org/&quot;&gt;&lt;b&gt;scarpe hogan&lt;/b&gt;&lt;/a&gt; <br />
hlolk <br />
&lt;a href=&quot;http://www.doudounemonclere-fra.com/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
fsbcs <br />
&lt;a href=&quot;http://www.nikefreerun2012-dk.com/&quot;&gt;&lt;b&gt;http://www.nikefreerun2012-dk.com/&lt;/b&gt;&lt;/a&gt; <br />
pfqjt <br />
&lt;a href=&quot;http://www.hogansitoufficialeui-italian.org/&quot;&gt;&lt;b&gt;http://www.hogansitoufficialeui-italian.org/&lt;/b&gt;&lt;/a&gt; qmcob xhfxa http://www.doudoun","2012-10-27 04:06:27","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("535","0","ydwotreniw","imjxwk@jmoaki.com","6YUX3f  <a href=\"http://wnzbfpfjbqjc.com/\">wnzbfpfjbqjc</a>, [url=http://hwiyifrswssb.com/]hwiyifrswssb[/url], [link=http://btcetxmihmqj.com/]btcetxmihmqj[/link], http://bdwdupylkaxy.com/","6YUX3f  &lt;a href=&quot;http://wnzbfpfjbqjc.com/&quot;&gt;wnzbfpfjbqjc&lt;/a&gt;, hwiyifrswssb, btcetxmihmqj, http://bdwdupylkaxy.com/","2012-10-27 11:27:46","13","0","-1");
INSERT INTO ltqri_slicomments VALUES("536","0","lsgvnaxmpt","rjllgm@mvjfmy.com","SNkUvy  <a href=\"http://wrlasxhwhynl.com/\">wrlasxhwhynl</a>, [url=http://oqewpnucjeme.com/]oqewpnucjeme[/url], [link=http://uixzjtxeicek.com/]uixzjtxeicek[/link], http://cxvuhpuqfwsq.com/","SNkUvy  &lt;a href=&quot;http://wrlasxhwhynl.com/&quot;&gt;wrlasxhwhynl&lt;/a&gt;, oqewpnucjeme, uixzjtxeicek, http://cxvuhpuqfwsq.com/","2012-10-27 20:16:56","15","0","-1");
INSERT INTO ltqri_slicomments VALUES("537","0","XRumerTest","shgnc8d2@gmail.com","anwdx 
<a href=\"http://www.saclouisvuittonpascherq.com/\"><b>sac louis vuitton</b></a> 
zonzw 
<a href=\"http://www.doudounemonclere-fra.com/\"><b>doudoune moncler</b></a> 
qcllb 
<a href=\"http://www.borselouisvuitton-italiane.com/\"><b>borse louis vuitton</b></a> 
etqmm 
<a href=\"http://www.saclouisvuittonpascherq.com/\"><b>http://www.saclouisvuittonpascherq.com/</b></a> 
ugrro 
<a href=\"http://www.doudounemonclere-fra.com/\"><b>http://www.doudounemonclere-fra.com/</b></a> dapjo  http://www.","anwdx <br />
&lt;a href=&quot;http://www.saclouisvuittonpascherq.com/&quot;&gt;&lt;b&gt;sac louis vuitton&lt;/b&gt;&lt;/a&gt; <br />
zonzw <br />
&lt;a href=&quot;http://www.doudounemonclere-fra.com/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
qcllb <br />
&lt;a href=&quot;http://www.borselouisvuitton-italiane.com/&quot;&gt;&lt;b&gt;borse louis vuitton&lt;/b&gt;&lt;/a&gt; <br />
etqmm <br />
&lt;a href=&quot;http://www.saclouisvuittonpascherq.com/&quot;&gt;&lt;b&gt;http://www.saclouisvuittonpascherq.com/&lt;/b&gt;&lt;/a&gt; <br />
ugrro <br />
&lt;a href=&quot;http://www.doudounemonclere-fra.com/&quot;&gt;&lt;b&gt;http://www.doudounemonclere-fra.com/&lt;/b&gt;&lt;/a&gt; dapjo  http://www.","2012-10-27 21:44:57","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("538","0","Braccimmite","gsxop9o7@gmail.com","bckyo 
<a href=\"http://www.hoganoutleteitalian.com/\"><b>hogan outlet</b></a> 
totir 
hqqnj 
<a href=\"http://www.borselouisvuitton-italiane.com/\"><b>louis vuitton borse</b></a> 
yxoip 
snqxh 
<a href=\"http://www.doudounemonclere-fra.com/\"><b>doudoune moncler</b></a> 
byjpe 
<a href=\"http://www.borselouisvuitton-italiane.com/\"><b>http://www.borselouisvuitton-italiane.com/</b></a> 
auzpz 
<a href=\"http://www.doudounemonclere-fra.com/\"><b>http://www.doudounemonclere-fra.com/</b></a> 
cox","bckyo <br />
&lt;a href=&quot;http://www.hoganoutleteitalian.com/&quot;&gt;&lt;b&gt;hogan outlet&lt;/b&gt;&lt;/a&gt; <br />
totir <br />
hqqnj <br />
&lt;a href=&quot;http://www.borselouisvuitton-italiane.com/&quot;&gt;&lt;b&gt;louis vuitton borse&lt;/b&gt;&lt;/a&gt; <br />
yxoip <br />
snqxh <br />
&lt;a href=&quot;http://www.doudounemonclere-fra.com/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
byjpe <br />
&lt;a href=&quot;http://www.borselouisvuitton-italiane.com/&quot;&gt;&lt;b&gt;http://www.borselouisvuitton-italiane.com/&lt;/b&gt;&lt;/a&gt; <br />
auzpz <br />
&lt;a href=&quot;http://www.doudounemonclere-fra.com/&quot;&gt;&lt;b&gt;http://www.doudounemonclere-fra.com/&lt;/b&gt;&lt;/a&gt; <br />
cox","2012-10-27 22:19:17","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("539","0","Katelyn","goodboy@yahoo.com","I\'m not interested in football <a href=\" http://www.kimbertonwholefoods.com \">cymbalta canada</a>  in sections 4.2 and 4.3.
 ","I&#039;m not interested in football &lt;a href=&quot; http://www.kimbertonwholefoods.com &quot;&gt;cymbalta canada&lt;/a&gt;  in sections 4.2 and 4.3.<br />
 ","2012-10-28 02:11:25","11","0","-1");
INSERT INTO ltqri_slicomments VALUES("540","0","Vefiblebinc","jzs718@titanmail.co.cc","But the truth is, Understanding <a href=http://www.nflstoreauthentic.com/nike+jared+allen+womens+youth+jersey-c-914_1147_1157.html>Jared Allen Women\'s Jersey</a>
 football odds is a piece of cake with the right instruction Quarterback Matt Schaub has rebounded from a broken foot that kept him out of Houston\'s postseason run last year to throw for 1,650 yards and 10 touchdownsBut he spent extra time during the offseason working on his conditioning, particularly his explosiveness, and he\'s been i","But the truth is, Understanding &lt;a href=http://www.nflstoreauthentic.com/nike+jared+allen+womens+youth+jersey-c-914_1147_1157.html&gt;Jared Allen Women&#039;s Jersey&lt;/a&gt;<br />
 football odds is a piece of cake with the right instruction Quarterback Matt Schaub has rebounded from a broken foot that kept him out of Houston&#039;s postseason run last year to throw for 1,650 yards and 10 touchdownsBut he spent extra time during the offseason working on his conditioning, particularly his explosiveness, and he&#039;s been i","2012-10-28 15:47:39","9","0","-1");
INSERT INTO ltqri_slicomments VALUES("541","0","XRumerTest","actse9m0@gmail.com","medsi 
<a href=\"http://www.saclongchampsaci2012.com/\"><b>sac longchamp pas cher</b></a> 
xoivk 
<a href=\"http://www.airjordanuboutique-fr.com/\"><b>air jordan femme</b></a> 
ofsum 
<a href=\"http://www.chaussuresslouboutinpascherl.net/\"><b>louboutin</b></a> 
raxsz 
<a href=\"http://www.hoganusitoufficialeu-italian.org/\"><b>hogan scarpe</b></a> 
zdvuj 
<a href=\"http://www.sacslouisvuittonppascher-fr.net/\"><b>louis vuitton pas cher</b></a> fapzi","medsi <br />
&lt;a href=&quot;http://www.saclongchampsaci2012.com/&quot;&gt;&lt;b&gt;sac longchamp pas cher&lt;/b&gt;&lt;/a&gt; <br />
xoivk <br />
&lt;a href=&quot;http://www.airjordanuboutique-fr.com/&quot;&gt;&lt;b&gt;air jordan femme&lt;/b&gt;&lt;/a&gt; <br />
ofsum <br />
&lt;a href=&quot;http://www.chaussuresslouboutinpascherl.net/&quot;&gt;&lt;b&gt;louboutin&lt;/b&gt;&lt;/a&gt; <br />
raxsz <br />
&lt;a href=&quot;http://www.hoganusitoufficialeu-italian.org/&quot;&gt;&lt;b&gt;hogan scarpe&lt;/b&gt;&lt;/a&gt; <br />
zdvuj <br />
&lt;a href=&quot;http://www.sacslouisvuittonppascher-fr.net/&quot;&gt;&lt;b&gt;louis vuitton pas cher&lt;/b&gt;&lt;/a&gt; fapzi","2012-10-28 16:41:17","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("542","0","dumSmoole","jxpbc3a1@gmail.com","gtzkt 
<a href=\"http://www.doudounemonclerpascherm.net/\"><b>moncler doudoune</b></a> 
wrynm 
<a href=\"http://www.burberrypascheriboutique.com/\"><b>burberry pas cher</b></a> 
mfcqq 
<a href=\"http://www.scarpehoganoutletl.com/\"><b>hogan</b></a> 
zpoqu 
<a href=\"http://www.canadagoosenorge2ol3.com/\"><b>canada goose jakker</b></a> 
mknaz 
<a href=\"http://www.monclerjassennlei.com/\"><b>moncler</b></a> ccspc","gtzkt <br />
&lt;a href=&quot;http://www.doudounemonclerpascherm.net/&quot;&gt;&lt;b&gt;moncler doudoune&lt;/b&gt;&lt;/a&gt; <br />
wrynm <br />
&lt;a href=&quot;http://www.burberrypascheriboutique.com/&quot;&gt;&lt;b&gt;burberry pas cher&lt;/b&gt;&lt;/a&gt; <br />
mfcqq <br />
&lt;a href=&quot;http://www.scarpehoganoutletl.com/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
zpoqu <br />
&lt;a href=&quot;http://www.canadagoosenorge2ol3.com/&quot;&gt;&lt;b&gt;canada goose jakker&lt;/b&gt;&lt;/a&gt; <br />
mknaz <br />
&lt;a href=&quot;http://www.monclerjassennlei.com/&quot;&gt;&lt;b&gt;moncler&lt;/b&gt;&lt;/a&gt; ccspc","2012-10-28 17:32:53","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("543","0","XRumerTest","eprxf9q6@gmail.com","oibob 
<a href=\"http://www.abercrombiepaschert.com/\"><b>abercrombie pas cher</b></a> 
aropa 
<a href=\"http://www.doudounemonclerb.com/\"><b>moncler</b></a> 
hhktr 
<a href=\"http://www.hogansitoufficialeu-italiian.org/\"><b>hogan outlet</b></a> 
vfioy 
<a href=\"http://www.abercrombiepaschert.com/\"><b>http://www.abercrombiepaschert.com/</b></a> 
fekaq 
<a href=\"http://www.doudounemonclerb.com/\"><b>http://www.doudounemonclerb.com/</b></a> dcvfn 
 
http://www.hogansitoufficialeu-italiian.or","oibob <br />
&lt;a href=&quot;http://www.abercrombiepaschert.com/&quot;&gt;&lt;b&gt;abercrombie pas cher&lt;/b&gt;&lt;/a&gt; <br />
aropa <br />
&lt;a href=&quot;http://www.doudounemonclerb.com/&quot;&gt;&lt;b&gt;moncler&lt;/b&gt;&lt;/a&gt; <br />
hhktr <br />
&lt;a href=&quot;http://www.hogansitoufficialeu-italiian.org/&quot;&gt;&lt;b&gt;hogan outlet&lt;/b&gt;&lt;/a&gt; <br />
vfioy <br />
&lt;a href=&quot;http://www.abercrombiepaschert.com/&quot;&gt;&lt;b&gt;http://www.abercrombiepaschert.com/&lt;/b&gt;&lt;/a&gt; <br />
fekaq <br />
&lt;a href=&quot;http://www.doudounemonclerb.com/&quot;&gt;&lt;b&gt;http://www.doudounemonclerb.com/&lt;/b&gt;&lt;/a&gt; dcvfn <br />
 <br />
http://www.hogansitoufficialeu-italiian.or","2012-10-28 21:21:10","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("544","0","XRumerTest","ysaoj5e3@gmail.com","mshkk 
<a href=\"http://www.abercrombiepaschert.com/\"><b>abercrombie</b></a> 
nvdeu 
<a href=\"http://www.doudounemonclerb.com/\"><b>doudoune moncler</b></a> 
aglxn 
<a href=\"http://www.hogansitoufficialeu-italiian.org/\"><b>hogan outlet</b></a> 
bhkev 
<a href=\"http://www.abercrombiepaschert.com/\"><b>http://www.abercrombiepaschert.com/</b></a> 
sageg 
<a href=\"http://www.doudounemonclerb.com/\"><b>http://www.doudounemonclerb.com/</b></a> aghbm 
 
http://www.hogansitoufficialeu-italiian.or","mshkk <br />
&lt;a href=&quot;http://www.abercrombiepaschert.com/&quot;&gt;&lt;b&gt;abercrombie&lt;/b&gt;&lt;/a&gt; <br />
nvdeu <br />
&lt;a href=&quot;http://www.doudounemonclerb.com/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
aglxn <br />
&lt;a href=&quot;http://www.hogansitoufficialeu-italiian.org/&quot;&gt;&lt;b&gt;hogan outlet&lt;/b&gt;&lt;/a&gt; <br />
bhkev <br />
&lt;a href=&quot;http://www.abercrombiepaschert.com/&quot;&gt;&lt;b&gt;http://www.abercrombiepaschert.com/&lt;/b&gt;&lt;/a&gt; <br />
sageg <br />
&lt;a href=&quot;http://www.doudounemonclerb.com/&quot;&gt;&lt;b&gt;http://www.doudounemonclerb.com/&lt;/b&gt;&lt;/a&gt; aghbm <br />
 <br />
http://www.hogansitoufficialeu-italiian.or","2012-10-28 22:25:48","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("545","0","XRumerTest","mutom7r8@gmail.com","sswmn 
<a href=\"http://www.hogansitoufficialeui-italian.org/\"><b>hogan</b></a> 
kxifp 
<a href=\"http://www.nikefree2012-dkt.com/\"><b>nike free run</b></a> 
frsky 
<a href=\"http://www.itescarpehogansitoufficiale.com/\"><b>hogan</b></a> 
bszba 
<a href=\"http://www.hogansitoufficialeui-italian.org/\"><b>http://www.hogansitoufficialeui-italian.org/</b></a> 
wjlax 
<a href=\"http://www.nikefree2012-dkt.com/\"><b>http://www.nikefree2012-dkt.com/</b></a> arfsy  http://www.itescarpehogansitoufficia","sswmn <br />
&lt;a href=&quot;http://www.hogansitoufficialeui-italian.org/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
kxifp <br />
&lt;a href=&quot;http://www.nikefree2012-dkt.com/&quot;&gt;&lt;b&gt;nike free run&lt;/b&gt;&lt;/a&gt; <br />
frsky <br />
&lt;a href=&quot;http://www.itescarpehogansitoufficiale.com/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
bszba <br />
&lt;a href=&quot;http://www.hogansitoufficialeui-italian.org/&quot;&gt;&lt;b&gt;http://www.hogansitoufficialeui-italian.org/&lt;/b&gt;&lt;/a&gt; <br />
wjlax <br />
&lt;a href=&quot;http://www.nikefree2012-dkt.com/&quot;&gt;&lt;b&gt;http://www.nikefree2012-dkt.com/&lt;/b&gt;&lt;/a&gt; arfsy  http://www.itescarpehogansitoufficia","2012-10-28 23:25:28","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("546","0","Braccimmite","lzfax9s3@gmail.com","yrese 
<a href=\"http://www.hoganoutleteitalian.com/\"><b>hogan</b></a> 
zobik 
elkzq 
<a href=\"http://www.borselouisvuitton-italiane.com/\"><b>louis vuitton borse</b></a> 
sytwm 
kysfa 
<a href=\"http://www.timberlandpascher-francet.com/\"><b>chaussure timberland</b></a> 
eelap 
<a href=\"http://www.borselouisvuitton-italiane.com/\"><b>http://www.borselouisvuitton-italiane.com/</b></a> 
nqthx 
<a href=\"http://www.hoganoutleteitalian.com/\"><b>http://www.hoganoutleteitalian.com/</b></a> beazv","yrese <br />
&lt;a href=&quot;http://www.hoganoutleteitalian.com/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
zobik <br />
elkzq <br />
&lt;a href=&quot;http://www.borselouisvuitton-italiane.com/&quot;&gt;&lt;b&gt;louis vuitton borse&lt;/b&gt;&lt;/a&gt; <br />
sytwm <br />
kysfa <br />
&lt;a href=&quot;http://www.timberlandpascher-francet.com/&quot;&gt;&lt;b&gt;chaussure timberland&lt;/b&gt;&lt;/a&gt; <br />
eelap <br />
&lt;a href=&quot;http://www.borselouisvuitton-italiane.com/&quot;&gt;&lt;b&gt;http://www.borselouisvuitton-italiane.com/&lt;/b&gt;&lt;/a&gt; <br />
nqthx <br />
&lt;a href=&quot;http://www.hoganoutleteitalian.com/&quot;&gt;&lt;b&gt;http://www.hoganoutleteitalian.com/&lt;/b&gt;&lt;/a&gt; beazv","2012-10-29 07:29:52","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("547","0","XRumerTest","xwmdb6e3@gmail.com","huptl 
<a href=\"http://www.doudounemonclerpascherm.net/\"><b>moncler pas cher</b></a> 
lnqcx 
<a href=\"http://www.burberrypascheriboutique.com/\"><b>burberry soldes</b></a> 
jdfew 
<a href=\"http://www.scarpehoganoutletl.com/\"><b>hogan outlet</b></a> 
lkdii 
<a href=\"http://www.canadagoosenorge2ol3.com/\"><b>canada goose jakke</b></a> 
rxats 
<a href=\"http://www.monclerjassennlei.com/\"><b>moncler muts</b></a> acqii","huptl <br />
&lt;a href=&quot;http://www.doudounemonclerpascherm.net/&quot;&gt;&lt;b&gt;moncler pas cher&lt;/b&gt;&lt;/a&gt; <br />
lnqcx <br />
&lt;a href=&quot;http://www.burberrypascheriboutique.com/&quot;&gt;&lt;b&gt;burberry soldes&lt;/b&gt;&lt;/a&gt; <br />
jdfew <br />
&lt;a href=&quot;http://www.scarpehoganoutletl.com/&quot;&gt;&lt;b&gt;hogan outlet&lt;/b&gt;&lt;/a&gt; <br />
lkdii <br />
&lt;a href=&quot;http://www.canadagoosenorge2ol3.com/&quot;&gt;&lt;b&gt;canada goose jakke&lt;/b&gt;&lt;/a&gt; <br />
rxats <br />
&lt;a href=&quot;http://www.monclerjassennlei.com/&quot;&gt;&lt;b&gt;moncler muts&lt;/b&gt;&lt;/a&gt; acqii","2012-10-30 03:53:50","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("548","0","dumSmoole","vfqxb5n1@gmail.com","ynkbz 
<a href=\"http://www.doudounemonclerpascherm.net/\"><b>doudoune moncler femme</b></a> 
yvage 
<a href=\"http://www.burberrypascheriboutique.com/\"><b>sac burberry</b></a> 
ajvnv 
<a href=\"http://www.scarpehoganoutletl.com/\"><b>scarpe hogan</b></a> 
dhati 
<a href=\"http://www.canadagoosenorge2ol3.com/\"><b>canada goose</b></a> 
fhvql 
<a href=\"http://www.monclerjassennlei.com/\"><b>moncler</b></a> ttuvg","ynkbz <br />
&lt;a href=&quot;http://www.doudounemonclerpascherm.net/&quot;&gt;&lt;b&gt;doudoune moncler femme&lt;/b&gt;&lt;/a&gt; <br />
yvage <br />
&lt;a href=&quot;http://www.burberrypascheriboutique.com/&quot;&gt;&lt;b&gt;sac burberry&lt;/b&gt;&lt;/a&gt; <br />
ajvnv <br />
&lt;a href=&quot;http://www.scarpehoganoutletl.com/&quot;&gt;&lt;b&gt;scarpe hogan&lt;/b&gt;&lt;/a&gt; <br />
dhati <br />
&lt;a href=&quot;http://www.canadagoosenorge2ol3.com/&quot;&gt;&lt;b&gt;canada goose&lt;/b&gt;&lt;/a&gt; <br />
fhvql <br />
&lt;a href=&quot;http://www.monclerjassennlei.com/&quot;&gt;&lt;b&gt;moncler&lt;/b&gt;&lt;/a&gt; ttuvg","2012-10-30 05:31:03","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("549","0","XRumerTest","hlpvb2f3@gmail.com","dbbap 
<a href=\"http://www.doudounemonclerpascherm.net/\"><b>doudoune moncler</b></a> 
jibvj 
<a href=\"http://www.burberrypascheriboutique.com/\"><b>burberry soldes</b></a> 
xddrp 
<a href=\"http://www.scarpehoganoutletl.com/\"><b>scarpe hogan</b></a> 
ezidf 
<a href=\"http://www.canadagoosenorge2ol3.com/\"><b>canada goose</b></a> 
librv 
<a href=\"http://www.monclerjassennlei.com/\"><b>moncler jassen</b></a> vrrxw","dbbap <br />
&lt;a href=&quot;http://www.doudounemonclerpascherm.net/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
jibvj <br />
&lt;a href=&quot;http://www.burberrypascheriboutique.com/&quot;&gt;&lt;b&gt;burberry soldes&lt;/b&gt;&lt;/a&gt; <br />
xddrp <br />
&lt;a href=&quot;http://www.scarpehoganoutletl.com/&quot;&gt;&lt;b&gt;scarpe hogan&lt;/b&gt;&lt;/a&gt; <br />
ezidf <br />
&lt;a href=&quot;http://www.canadagoosenorge2ol3.com/&quot;&gt;&lt;b&gt;canada goose&lt;/b&gt;&lt;/a&gt; <br />
librv <br />
&lt;a href=&quot;http://www.monclerjassennlei.com/&quot;&gt;&lt;b&gt;moncler jassen&lt;/b&gt;&lt;/a&gt; vrrxw","2012-10-30 05:31:13","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("550","0","appapyriree","kickfans110@gmail.com","<a href=http://www.christianlouboutinsaus.com/christian-louboutin-pumps-shoes-c-9.html>christian louboutin pumps shoes</a>
 
<a href=\"http://www.christianlouboutinsaus.com/christian-louboutin-boots-shoes-c-6.html\">christian louboutin discount</a>
","&lt;a href=http://www.christianlouboutinsaus.com/christian-louboutin-pumps-shoes-c-9.html&gt;christian louboutin pumps shoes&lt;/a&gt;<br />
 <br />
&lt;a href=&quot;http://www.christianlouboutinsaus.com/christian-louboutin-boots-shoes-c-6.html&quot;&gt;christian louboutin discount&lt;/a&gt;<br />
","2012-10-30 06:05:57","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("551","0","ffsdfs","fdasfds@dasas.com","dfsafsdfsdf","dfsafsdfsdf","2012-10-30 17:56:16","3","0","-2");
INSERT INTO ltqri_slicomments VALUES("552","0","Braccimmite","xnhjg2q5@gmail.com","wbyce 
<a href=\"http://www.doudounemonclerdoudounee.info/\"><b>moncler doudoune</b></a> 
tbvwv 
<a href=\"http://www.hogansitoufficialeu-italian3.info/\"><b>hogan</b></a> 
ninzy 
<a href=\"http://hogansitoufficialeu-italian4.info/\"><b>hogan outlet</b></a> 
stjmm 
<a href=\"http://burberrypascherboutiquet.com/\"><b>burberry</b></a> 
xkcjl 
<a href=\"http://www.saclongchamppascherv.com/\"><b>longchamp sac</b></a> hkzvl","wbyce <br />
&lt;a href=&quot;http://www.doudounemonclerdoudounee.info/&quot;&gt;&lt;b&gt;moncler doudoune&lt;/b&gt;&lt;/a&gt; <br />
tbvwv <br />
&lt;a href=&quot;http://www.hogansitoufficialeu-italian3.info/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
ninzy <br />
&lt;a href=&quot;http://hogansitoufficialeu-italian4.info/&quot;&gt;&lt;b&gt;hogan outlet&lt;/b&gt;&lt;/a&gt; <br />
stjmm <br />
&lt;a href=&quot;http://burberrypascherboutiquet.com/&quot;&gt;&lt;b&gt;burberry&lt;/b&gt;&lt;/a&gt; <br />
xkcjl <br />
&lt;a href=&quot;http://www.saclongchamppascherv.com/&quot;&gt;&lt;b&gt;longchamp sac&lt;/b&gt;&lt;/a&gt; hkzvl","2012-10-30 18:17:13","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("553","0","Snisppsymnnal","yfyziu5a2@gmail.com","pidpo 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>doudoune moncler</b></a> 
ogcwp 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie france</b></a> 
ftuvv 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>louboutin pas cher</b></a> 
icjpf 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan scarpe</b></a> 
wtehy 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>the north face</b></a> rknif","pidpo <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
ogcwp <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie france&lt;/b&gt;&lt;/a&gt; <br />
ftuvv <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;louboutin pas cher&lt;/b&gt;&lt;/a&gt; <br />
icjpf <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan scarpe&lt;/b&gt;&lt;/a&gt; <br />
wtehy <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;the north face&lt;/b&gt;&lt;/a&gt; rknif","2012-10-30 23:06:59","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("554","0","Snisppsymnnal","tuchpl5r9@gmail.com","qkyih 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>moncler</b></a> 
pvfnm 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie</b></a> 
mqcgb 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>louboutin pas cher</b></a> 
lxikb 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan</b></a> 
pvgbu 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>north face sale</b></a> acuiz","qkyih <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;moncler&lt;/b&gt;&lt;/a&gt; <br />
pvfnm <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie&lt;/b&gt;&lt;/a&gt; <br />
mqcgb <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;louboutin pas cher&lt;/b&gt;&lt;/a&gt; <br />
lxikb <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
pvgbu <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;north face sale&lt;/b&gt;&lt;/a&gt; acuiz","2012-10-30 23:07:23","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("555","0","Snisppsymnnal","vwnsom7d2@gmail.com","lbvix 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>doudoune moncler</b></a> 
youax 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie</b></a> 
ihvqk 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>chaussures louboutin</b></a> 
pfmde 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan scarpe</b></a> 
yhfre 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>north face sale</b></a> hdkwn","lbvix <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
youax <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie&lt;/b&gt;&lt;/a&gt; <br />
ihvqk <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;chaussures louboutin&lt;/b&gt;&lt;/a&gt; <br />
pfmde <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan scarpe&lt;/b&gt;&lt;/a&gt; <br />
yhfre <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;north face sale&lt;/b&gt;&lt;/a&gt; hdkwn","2012-10-30 23:46:10","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("556","0","Francesco Banda Jasso","vingplaz@msn.com","You actually make it seem so easy with your presentation but I find this matter to be actually something which I think I would never understand. It seems too complicated and very broad for me. I\'m looking forward for your next post, I\'ll try to get the hang of it!","You actually make it seem so easy with your presentation but I find this matter to be actually something which I think I would never understand. It seems too complicated and very broad for me. I&#039;m looking forward for your next post, I&#039;ll try to get the hang of it!","2012-10-31 06:44:02","26","0","-1");
INSERT INTO ltqri_slicomments VALUES("557","0","XRumerTest","tupll2h3@gmail.com","bvwwm 
<a href=\"http://www.sacslouisvuittonipascher-fr.net/\"><b>louis vuitton pas cher</b></a> 
qsoeu 
<a href=\"http://www.piuminimonclerti.com/\"><b>moncler outlet</b></a> 
coybf 
<a href=\"http://www.borselouisvuittonoutlettitalian.net/\"><b>louis vuitton borse</b></a> 
odxaa 
<a href=\"http://www.sacslouisvuittonipascher-fr.net/\"><b>http://www.sacslouisvuittonipascher-fr.net/</b></a> 
dceai 
<a href=\"http://www.piuminimonclerti.com/\"><b>http://www.piuminimonclerti.com/</b></a> tufyk   ht","bvwwm <br />
&lt;a href=&quot;http://www.sacslouisvuittonipascher-fr.net/&quot;&gt;&lt;b&gt;louis vuitton pas cher&lt;/b&gt;&lt;/a&gt; <br />
qsoeu <br />
&lt;a href=&quot;http://www.piuminimonclerti.com/&quot;&gt;&lt;b&gt;moncler outlet&lt;/b&gt;&lt;/a&gt; <br />
coybf <br />
&lt;a href=&quot;http://www.borselouisvuittonoutlettitalian.net/&quot;&gt;&lt;b&gt;louis vuitton borse&lt;/b&gt;&lt;/a&gt; <br />
odxaa <br />
&lt;a href=&quot;http://www.sacslouisvuittonipascher-fr.net/&quot;&gt;&lt;b&gt;http://www.sacslouisvuittonipascher-fr.net/&lt;/b&gt;&lt;/a&gt; <br />
dceai <br />
&lt;a href=&quot;http://www.piuminimonclerti.com/&quot;&gt;&lt;b&gt;http://www.piuminimonclerti.com/&lt;/b&gt;&lt;/a&gt; tufyk   ht","2012-10-31 17:44:24","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("558","0","dumSmoole","krtfg6q1@gmail.com","cvsgn 
<a href=\"http://www.sacslouisvuittonipascher-fr.net/\"><b>sac louis vuitton</b></a> 
qjfyg 
<a href=\"http://www.piuminimonclerti.com/\"><b>moncler</b></a> 
llyrc 
<a href=\"http://www.borselouisvuittonoutlettitalian.net/\"><b>louis vuitton borse</b></a> 
knkoz 
<a href=\"http://www.sacslouisvuittonipascher-fr.net/\"><b>http://www.sacslouisvuittonipascher-fr.net/</b></a> 
ywigy 
<a href=\"http://www.piuminimonclerti.com/\"><b>http://www.piuminimonclerti.com/</b></a> mrpza   http://www.bor","cvsgn <br />
&lt;a href=&quot;http://www.sacslouisvuittonipascher-fr.net/&quot;&gt;&lt;b&gt;sac louis vuitton&lt;/b&gt;&lt;/a&gt; <br />
qjfyg <br />
&lt;a href=&quot;http://www.piuminimonclerti.com/&quot;&gt;&lt;b&gt;moncler&lt;/b&gt;&lt;/a&gt; <br />
llyrc <br />
&lt;a href=&quot;http://www.borselouisvuittonoutlettitalian.net/&quot;&gt;&lt;b&gt;louis vuitton borse&lt;/b&gt;&lt;/a&gt; <br />
knkoz <br />
&lt;a href=&quot;http://www.sacslouisvuittonipascher-fr.net/&quot;&gt;&lt;b&gt;http://www.sacslouisvuittonipascher-fr.net/&lt;/b&gt;&lt;/a&gt; <br />
ywigy <br />
&lt;a href=&quot;http://www.piuminimonclerti.com/&quot;&gt;&lt;b&gt;http://www.piuminimonclerti.com/&lt;/b&gt;&lt;/a&gt; mrpza   http://www.bor","2012-10-31 18:09:32","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("559","0","pluto1","pluto@yahoo.com","molto interessante l\'articolo","molto interessante l&#039;articolo","2012-10-31 18:44:57","35","0","-2");
INSERT INTO ltqri_slicomments VALUES("560","0","Lily","nogood87@yahoo.com","I\'m a partner in  <a href=\" http://www.lowvillegolf.com \">best online sites generic viagra</a>  as appropriate to distress, level of interpret heart rate and
 ","I&#039;m a partner in  &lt;a href=&quot; http://www.lowvillegolf.com &quot;&gt;best online sites generic viagra&lt;/a&gt;  as appropriate to distress, level of interpret heart rate and<br />
 ","2012-10-31 23:18:06","11","0","-1");
INSERT INTO ltqri_slicomments VALUES("561","0","AssilkAnads","jack760wolfgagbs1kin@gmail.com","<a href=\"http://www.jackwolfskin-online.com/#83596\">Jack Wolfskin Outlet</a>,f6ct26, <a href=\"http://www.jackwolfskin-online.com/#57035\">Jack Wolfskin Jacket</a>,v9qa34, <a href=\"http://www.jackwolfskin-online.com/#46628\">Jack Wolfskin Online Shop</a>,i3de67, <a href=\"http://www.jackwolfskin-online.com/#51051\">Jack Wolfskin Sale</a>,k6hg33, ","&lt;a href=&quot;http://www.jackwolfskin-online.com/#83596&quot;&gt;Jack Wolfskin Outlet&lt;/a&gt;,f6ct26, &lt;a href=&quot;http://www.jackwolfskin-online.com/#57035&quot;&gt;Jack Wolfskin Jacket&lt;/a&gt;,v9qa34, &lt;a href=&quot;http://www.jackwolfskin-online.com/#46628&quot;&gt;Jack Wolfskin Online Shop&lt;/a&gt;,i3de67, &lt;a href=&quot;http://www.jackwolfskin-online.com/#51051&quot;&gt;Jack Wolfskin Sale&lt;/a&gt;,k6hg33, ","2012-11-01 05:53:39","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("562","0","UsesBelfkef","jack760wolfsdsvs1kin@gmail.com","<a href=\"http://www.jackwolfskin-online.com/#17506\">Jack Wolfskin Online Shop</a>,z7go00, <a href=\"http://www.jackwolfskin-online.com/#63908\">Jack Wolfskin Jacket</a>,m9jr88, <a href=\"http://www.jackwolfskin-online.com/#24346\">Jack Wolfskin</a>,y7ji21, <a href=\"http://www.jackwolfskin-online.com/#66622\">Jack Wolfskin Sale</a>,l3rs62, ","&lt;a href=&quot;http://www.jackwolfskin-online.com/#17506&quot;&gt;Jack Wolfskin Online Shop&lt;/a&gt;,z7go00, &lt;a href=&quot;http://www.jackwolfskin-online.com/#63908&quot;&gt;Jack Wolfskin Jacket&lt;/a&gt;,m9jr88, &lt;a href=&quot;http://www.jackwolfskin-online.com/#24346&quot;&gt;Jack Wolfskin&lt;/a&gt;,y7ji21, &lt;a href=&quot;http://www.jackwolfskin-online.com/#66622&quot;&gt;Jack Wolfskin Sale&lt;/a&gt;,l3rs62, ","2012-11-01 05:53:39","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("563","0","AmokeWelm","jack760wolfs1kisdgvfn@gmail.com","<a href=\"http://www.jackwolfskin-online.com/#76908\">Jack Wolfskin Jacket</a>,o3ht01, <a href=\"http://www.jackwolfskin-online.com/#67018\">Jack Wolfskin</a>,d5ak57, <a href=\"http://www.jackwolfskin-online.com/#54309\">Jack Wolfskin Sale</a>,i5wm30, <a href=\"http://www.jackwolfskin-online.com/#39956\">Jack Wolfskin Online Shop</a>,w8jb38, ","&lt;a href=&quot;http://www.jackwolfskin-online.com/#76908&quot;&gt;Jack Wolfskin Jacket&lt;/a&gt;,o3ht01, &lt;a href=&quot;http://www.jackwolfskin-online.com/#67018&quot;&gt;Jack Wolfskin&lt;/a&gt;,d5ak57, &lt;a href=&quot;http://www.jackwolfskin-online.com/#54309&quot;&gt;Jack Wolfskin Sale&lt;/a&gt;,i5wm30, &lt;a href=&quot;http://www.jackwolfskin-online.com/#39956&quot;&gt;Jack Wolfskin Online Shop&lt;/a&gt;,w8jb38, ","2012-11-01 05:53:51","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("564","0","ScadotagSyday","jack760wolfs1kin@gmail.com","<a href=\"http://www.jackwolfskin-online.com/#54693\">Jack Wolfskin Sale</a>,x7eg25, <a href=\"http://www.jackwolfskin-online.com/#76222\">Jack Wolfskin Jacket</a>,k2gp63, <a href=\"http://www.jackwolfskin-online.com/#49445\">Jack Wolfskin Online Shop</a>,e2uf88, <a href=\"http://www.jackwolfskin-online.com/#88291\">Jack Wolfskin</a>,m4qs56, ","&lt;a href=&quot;http://www.jackwolfskin-online.com/#54693&quot;&gt;Jack Wolfskin Sale&lt;/a&gt;,x7eg25, &lt;a href=&quot;http://www.jackwolfskin-online.com/#76222&quot;&gt;Jack Wolfskin Jacket&lt;/a&gt;,k2gp63, &lt;a href=&quot;http://www.jackwolfskin-online.com/#49445&quot;&gt;Jack Wolfskin Online Shop&lt;/a&gt;,e2uf88, &lt;a href=&quot;http://www.jackwolfskin-online.com/#88291&quot;&gt;Jack Wolfskin&lt;/a&gt;,m4qs56, ","2012-11-01 05:54:32","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("565","0","Choowhelt","jack760wolfs1kin12345235@gmail.com","<a href=\"http://www.jackwolfskin-online.com/#12288\">Jack Wolfskin Outlet</a>,k6vv40, <a href=\"http://www.jackwolfskin-online.com/#82300\">Jack Wolfskin Sale</a>,k6fa61, <a href=\"http://www.jackwolfskin-online.com/#17556\">Jack Wolfskin Jacket</a>,l3ym27, <a href=\"http://www.jackwolfskin-online.com/#75981\">Jack Wolfskin</a>,p0xs08, ","&lt;a href=&quot;http://www.jackwolfskin-online.com/#12288&quot;&gt;Jack Wolfskin Outlet&lt;/a&gt;,k6vv40, &lt;a href=&quot;http://www.jackwolfskin-online.com/#82300&quot;&gt;Jack Wolfskin Sale&lt;/a&gt;,k6fa61, &lt;a href=&quot;http://www.jackwolfskin-online.com/#17556&quot;&gt;Jack Wolfskin Jacket&lt;/a&gt;,l3ym27, &lt;a href=&quot;http://www.jackwolfskin-online.com/#75981&quot;&gt;Jack Wolfskin&lt;/a&gt;,p0xs08, ","2012-11-01 06:01:53","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("566","0","ScadotagSyday","jack760wagvolfs1kin@gmail.com","<a href=\"http://www.jackwolfskin-online.com/#34486\">Jack Wolfskin Jacket</a>,j7cq23, <a href=\"http://www.jackwolfskin-online.com/#71957\">Jack Wolfskin Outlet</a>,s7vj60, <a href=\"http://www.jackwolfskin-online.com/#23206\">Jack Wolfskin</a>,g4jc22, <a href=\"http://www.jackwolfskin-online.com/#96377\">Jack Wolfskin Online Shop</a>,s8na27, ","&lt;a href=&quot;http://www.jackwolfskin-online.com/#34486&quot;&gt;Jack Wolfskin Jacket&lt;/a&gt;,j7cq23, &lt;a href=&quot;http://www.jackwolfskin-online.com/#71957&quot;&gt;Jack Wolfskin Outlet&lt;/a&gt;,s7vj60, &lt;a href=&quot;http://www.jackwolfskin-online.com/#23206&quot;&gt;Jack Wolfskin&lt;/a&gt;,g4jc22, &lt;a href=&quot;http://www.jackwolfskin-online.com/#96377&quot;&gt;Jack Wolfskin Online Shop&lt;/a&gt;,s8na27, ","2012-11-01 06:04:19","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("567","0","Carkoccarty","xarlxs5b4@gmail.com","jjttn 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>moncler pas cher</b></a> 
jmehm 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie pas cher</b></a> 
pcbrv 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>chaussures louboutin</b></a> 
osohz 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan outlet</b></a> 
fdwfw 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>north face jackets</b></a> zzvjx","jjttn <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;moncler pas cher&lt;/b&gt;&lt;/a&gt; <br />
jmehm <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie pas cher&lt;/b&gt;&lt;/a&gt; <br />
pcbrv <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;chaussures louboutin&lt;/b&gt;&lt;/a&gt; <br />
osohz <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan outlet&lt;/b&gt;&lt;/a&gt; <br />
fdwfw <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;north face jackets&lt;/b&gt;&lt;/a&gt; zzvjx","2012-11-01 12:54:34","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("568","0","Carkoccarty","nxdqwg9l9@gmail.com","qpdee 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>doudoune moncler</b></a> 
zaftk 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie france</b></a> 
vljij 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>louboutin</b></a> 
eimyw 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan scarpe</b></a> 
blvgr 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>north face jackets</b></a> gmlhk","qpdee <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
zaftk <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie france&lt;/b&gt;&lt;/a&gt; <br />
vljij <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;louboutin&lt;/b&gt;&lt;/a&gt; <br />
eimyw <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan scarpe&lt;/b&gt;&lt;/a&gt; <br />
blvgr <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;north face jackets&lt;/b&gt;&lt;/a&gt; gmlhk","2012-11-01 12:54:34","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("569","0","Carkoccarty","oaqcul7f3@gmail.com","pgwvr 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>moncler pas cher</b></a> 
fkxze 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie france</b></a> 
dptie 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>louboutin</b></a> 
keoeb 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan</b></a> 
ugvzy 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>north face uk</b></a> mgtgp","pgwvr <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;moncler pas cher&lt;/b&gt;&lt;/a&gt; <br />
fkxze <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie france&lt;/b&gt;&lt;/a&gt; <br />
dptie <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;louboutin&lt;/b&gt;&lt;/a&gt; <br />
keoeb <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
ugvzy <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;north face uk&lt;/b&gt;&lt;/a&gt; mgtgp","2012-11-01 12:55:51","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("570","0","UnfomsnemsFex","ehwli8c9@gmail.com","ohsjw 
<a href=\"http://www.sacslouisvuittonipascher-fr.net/\"><b>louis vuitton pas cher</b></a> 
msirz 
<a href=\"http://www.piuminimonclerti.com/\"><b>moncler outlet</b></a> 
xwfho 
<a href=\"http://www.borselouisvuittonoutlettitalian.net/\"><b>borse louis vuitton</b></a> 
ozrdu 
<a href=\"http://www.sacslouisvuittonipascher-fr.net/\"><b>http://www.sacslouisvuittonipascher-fr.net/</b></a> 
qjbtz 
<a href=\"http://www.piuminimonclerti.com/\"><b>http://www.piuminimonclerti.com/</b></a> hastu   ht","ohsjw <br />
&lt;a href=&quot;http://www.sacslouisvuittonipascher-fr.net/&quot;&gt;&lt;b&gt;louis vuitton pas cher&lt;/b&gt;&lt;/a&gt; <br />
msirz <br />
&lt;a href=&quot;http://www.piuminimonclerti.com/&quot;&gt;&lt;b&gt;moncler outlet&lt;/b&gt;&lt;/a&gt; <br />
xwfho <br />
&lt;a href=&quot;http://www.borselouisvuittonoutlettitalian.net/&quot;&gt;&lt;b&gt;borse louis vuitton&lt;/b&gt;&lt;/a&gt; <br />
ozrdu <br />
&lt;a href=&quot;http://www.sacslouisvuittonipascher-fr.net/&quot;&gt;&lt;b&gt;http://www.sacslouisvuittonipascher-fr.net/&lt;/b&gt;&lt;/a&gt; <br />
qjbtz <br />
&lt;a href=&quot;http://www.piuminimonclerti.com/&quot;&gt;&lt;b&gt;http://www.piuminimonclerti.com/&lt;/b&gt;&lt;/a&gt; hastu   ht","2012-11-02 16:00:28","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("571","0","Choowhelt","jack760wolfs1kin12345235@gmail.com","<a href=\"http://arcteryxsale.webs.com/#49138\">Arcteryx Jackets</a>,h2ir81, <a href=\"http://www.jackwolfskin-online.com/#65986\">Jack Wolfskin Outlet</a>,l6gy97, <a href=\"http://www.jackwolfskin-online.com/#96368\">Jack Wolfskin Online Shop</a>,t4gt89, <a href=\"http://www.canadagoosetobuy.com/#89965\">Canada Goose Sale</a>,w0uq57, ","&lt;a href=&quot;http://arcteryxsale.webs.com/#49138&quot;&gt;Arcteryx Jackets&lt;/a&gt;,h2ir81, &lt;a href=&quot;http://www.jackwolfskin-online.com/#65986&quot;&gt;Jack Wolfskin Outlet&lt;/a&gt;,l6gy97, &lt;a href=&quot;http://www.jackwolfskin-online.com/#96368&quot;&gt;Jack Wolfskin Online Shop&lt;/a&gt;,t4gt89, &lt;a href=&quot;http://www.canadagoosetobuy.com/#89965&quot;&gt;Canada Goose Sale&lt;/a&gt;,w0uq57, ","2012-11-03 00:21:43","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("572","0","AmokeWelm","jack760wolfs1kisdgvfn@gmail.com","<a href=\"http://canadagoosesalecheap.webs.com/#87621\">Canada Goose Cheap</a>,p4pu72, <a href=\"http://canadagoosesalecheap.webs.com/#52004\">Canada Goose Sale</a>,e4mv66, <a href=\"http://www.jackwolfskin-online.com/#90108\">Jack Wolfskin Sale</a>,e2zc92, <a href=\"http://www.canadagoosetobuy.com/#20791\">Canada Goose Jackets</a>,l9op68, ","&lt;a href=&quot;http://canadagoosesalecheap.webs.com/#87621&quot;&gt;Canada Goose Cheap&lt;/a&gt;,p4pu72, &lt;a href=&quot;http://canadagoosesalecheap.webs.com/#52004&quot;&gt;Canada Goose Sale&lt;/a&gt;,e4mv66, &lt;a href=&quot;http://www.jackwolfskin-online.com/#90108&quot;&gt;Jack Wolfskin Sale&lt;/a&gt;,e2zc92, &lt;a href=&quot;http://www.canadagoosetobuy.com/#20791&quot;&gt;Canada Goose Jackets&lt;/a&gt;,l9op68, ","2012-11-03 00:23:45","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("573","0","AssilkAnads","jack760wolfgagbs1kin@gmail.com","<a href=\"http://www.jackwolfskin-online.com/#79530\">Jack Wolfskin</a>,w1ab63, <a href=\"http://www.jackwolfskin-online.com/#93456\">Jack Wolfskin Jacket</a>,m7dj71, <a href=\"http://Canadagoose-jackets.webs.com/#91493\">Canada Goose Outlet</a>,g2tb06, <a href=\"http://arcteryxjacketsale.webs.com/#13244\">Arcteryx Jackets</a>,f1md23, ","&lt;a href=&quot;http://www.jackwolfskin-online.com/#79530&quot;&gt;Jack Wolfskin&lt;/a&gt;,w1ab63, &lt;a href=&quot;http://www.jackwolfskin-online.com/#93456&quot;&gt;Jack Wolfskin Jacket&lt;/a&gt;,m7dj71, &lt;a href=&quot;http://Canadagoose-jackets.webs.com/#91493&quot;&gt;Canada Goose Outlet&lt;/a&gt;,g2tb06, &lt;a href=&quot;http://arcteryxjacketsale.webs.com/#13244&quot;&gt;Arcteryx Jackets&lt;/a&gt;,f1md23, ","2012-11-03 02:34:00","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("574","0","ScadotagSyday","jack760wagvolfs1kin@gmail.com","<a href=\"http://www.canadagoosetobuy.com/#56121\">Canada Goose Sale</a>,z5if29, <a href=\"http://arcteryxjacketsale.webs.com/#77704\">Arcteryx Sale</a>,u3hs51, <a href=\"http://arcteryxsale.webs.com/#25041\">Arcteryx</a>,a5wd52, <a href=\"http://cheapcanadagoosesale.webs.com/#96704\">Canada Goose Sale</a>,s5wz04, ","&lt;a href=&quot;http://www.canadagoosetobuy.com/#56121&quot;&gt;Canada Goose Sale&lt;/a&gt;,z5if29, &lt;a href=&quot;http://arcteryxjacketsale.webs.com/#77704&quot;&gt;Arcteryx Sale&lt;/a&gt;,u3hs51, &lt;a href=&quot;http://arcteryxsale.webs.com/#25041&quot;&gt;Arcteryx&lt;/a&gt;,a5wd52, &lt;a href=&quot;http://cheapcanadagoosesale.webs.com/#96704&quot;&gt;Canada Goose Sale&lt;/a&gt;,s5wz04, ","2012-11-03 03:09:21","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("575","0","Odonsedeeve","cymxo3f5@gmail.com","ectmz 
<a href=\"http://www.doudounemonclerdoudounee.info/\"><b>doudoune moncler</b></a> 
zcaxk 
<a href=\"http://www.hogansitoufficialeu-italian3.info/\"><b>hogan outlet</b></a> 
pgmlu 
<a href=\"http://hogansitoufficialeu-italian4.info/\"><b>scarpe hogan</b></a> 
mmqfz 
<a href=\"http://burberrypascherboutiquet.com/\"><b>sac burberry</b></a> 
mzcmf 
<a href=\"http://www.saclongchamppascherv.com/\"><b>sac longchamp pas cher</b></a> xfpj 
 
o","ectmz <br />
&lt;a href=&quot;http://www.doudounemonclerdoudounee.info/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
zcaxk <br />
&lt;a href=&quot;http://www.hogansitoufficialeu-italian3.info/&quot;&gt;&lt;b&gt;hogan outlet&lt;/b&gt;&lt;/a&gt; <br />
pgmlu <br />
&lt;a href=&quot;http://hogansitoufficialeu-italian4.info/&quot;&gt;&lt;b&gt;scarpe hogan&lt;/b&gt;&lt;/a&gt; <br />
mmqfz <br />
&lt;a href=&quot;http://burberrypascherboutiquet.com/&quot;&gt;&lt;b&gt;sac burberry&lt;/b&gt;&lt;/a&gt; <br />
mzcmf <br />
&lt;a href=&quot;http://www.saclongchamppascherv.com/&quot;&gt;&lt;b&gt;sac longchamp pas cher&lt;/b&gt;&lt;/a&gt; xfpj <br />
 <br />
o","2012-11-03 04:31:07","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("576","0","Carkoccarty","gcjjho6e7@gmail.com","luhoj 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>doudoune moncler</b></a> 
idibf 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie pas cher</b></a> 
zqfim 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>louboutin</b></a> 
mjlpy 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan outlet</b></a> 
tsdkl 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>north face sale</b></a> pfdcs","luhoj <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
idibf <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie pas cher&lt;/b&gt;&lt;/a&gt; <br />
zqfim <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;louboutin&lt;/b&gt;&lt;/a&gt; <br />
mjlpy <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan outlet&lt;/b&gt;&lt;/a&gt; <br />
tsdkl <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;north face sale&lt;/b&gt;&lt;/a&gt; pfdcs","2012-11-03 04:36:57","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("577","0","Carkoccarty","ooswmf4j6@gmail.com","qgvou 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>moncler pas cher</b></a> 
mvvit 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie france</b></a> 
askfa 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>louboutin pas cher</b></a> 
qpikj 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan outlet</b></a> 
taukb 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>north face uk</b></a> jubzd","qgvou <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;moncler pas cher&lt;/b&gt;&lt;/a&gt; <br />
mvvit <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie france&lt;/b&gt;&lt;/a&gt; <br />
askfa <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;louboutin pas cher&lt;/b&gt;&lt;/a&gt; <br />
qpikj <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan outlet&lt;/b&gt;&lt;/a&gt; <br />
taukb <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;north face uk&lt;/b&gt;&lt;/a&gt; jubzd","2012-11-03 04:36:59","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("578","0","Odonsedeeve","ekbzn6c2@gmail.com","qdnlz 
<a href=\"http://doudounemonclerdoudounea.info/\"><b>doudoune moncler</b></a> 
eulml 
<a href=\"http://hogansprezzihogan2012.info/\"><b>hogan</b></a> 
kgytx 
<a href=\"http://www.vetementpoloralphlaurens20l2.net/\"><b>polo ralph lauren pas cher</b></a> 
qhrke 
<a href=\"http://doudounemonclerdoudounea.info/\"><b>http://doudounemonclerdoudounea.info/</b></a> 
xlfps 
<a href=\"http://hogansprezzihogan2012.info/\"><b>http://hogansprezzihogan2012.info/</b></a> zhdof 
 
http://www.vetementpol","qdnlz <br />
&lt;a href=&quot;http://doudounemonclerdoudounea.info/&quot;&gt;&lt;b&gt;doudoune moncler&lt;/b&gt;&lt;/a&gt; <br />
eulml <br />
&lt;a href=&quot;http://hogansprezzihogan2012.info/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
kgytx <br />
&lt;a href=&quot;http://www.vetementpoloralphlaurens20l2.net/&quot;&gt;&lt;b&gt;polo ralph lauren pas cher&lt;/b&gt;&lt;/a&gt; <br />
qhrke <br />
&lt;a href=&quot;http://doudounemonclerdoudounea.info/&quot;&gt;&lt;b&gt;http://doudounemonclerdoudounea.info/&lt;/b&gt;&lt;/a&gt; <br />
xlfps <br />
&lt;a href=&quot;http://hogansprezzihogan2012.info/&quot;&gt;&lt;b&gt;http://hogansprezzihogan2012.info/&lt;/b&gt;&lt;/a&gt; zhdof <br />
 <br />
http://www.vetementpol","2012-11-03 10:37:48","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("579","0","Carkoccarty","lihagv9o3@gmail.com","atdgo 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>moncler</b></a> 
vgmkc 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie pas cher</b></a> 
knoxk 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>louboutin</b></a> 
ofilj 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan</b></a> 
fzslu 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>north face uk</b></a> wvihn","atdgo <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;moncler&lt;/b&gt;&lt;/a&gt; <br />
vgmkc <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie pas cher&lt;/b&gt;&lt;/a&gt; <br />
knoxk <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;louboutin&lt;/b&gt;&lt;/a&gt; <br />
ofilj <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
fzslu <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;north face uk&lt;/b&gt;&lt;/a&gt; wvihn","2012-11-03 13:33:41","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("580","0","Odonsedeeve","sucgv6f9@gmail.com","nyqsy 
<a href=\"http://doudounemonclerdoudounea.info/\"><b>moncler Pas Cher</b></a> 
rxdym 
<a href=\"http://hogansprezzihogan2012.info/\"><b>hogan</b></a> 
ixshi 
<a href=\"http://www.vetementpoloralphlaurens20l2.net/\"><b>ralph lauren pas cher</b></a> 
kgnlt 
<a href=\"http://doudounemonclerdoudounea.info/\"><b>http://doudounemonclerdoudounea.info/</b></a> 
qpfcc 
<a href=\"http://hogansprezzihogan2012.info/\"><b>http://hogansprezzihogan2012.info/</b></a> iqndb 
 
http://www.vetementpoloralp","nyqsy <br />
&lt;a href=&quot;http://doudounemonclerdoudounea.info/&quot;&gt;&lt;b&gt;moncler Pas Cher&lt;/b&gt;&lt;/a&gt; <br />
rxdym <br />
&lt;a href=&quot;http://hogansprezzihogan2012.info/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
ixshi <br />
&lt;a href=&quot;http://www.vetementpoloralphlaurens20l2.net/&quot;&gt;&lt;b&gt;ralph lauren pas cher&lt;/b&gt;&lt;/a&gt; <br />
kgnlt <br />
&lt;a href=&quot;http://doudounemonclerdoudounea.info/&quot;&gt;&lt;b&gt;http://doudounemonclerdoudounea.info/&lt;/b&gt;&lt;/a&gt; <br />
qpfcc <br />
&lt;a href=&quot;http://hogansprezzihogan2012.info/&quot;&gt;&lt;b&gt;http://hogansprezzihogan2012.info/&lt;/b&gt;&lt;/a&gt; iqndb <br />
 <br />
http://www.vetementpoloralp","2012-11-03 14:31:39","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("581","0","UnfomsnemsFex","tkncs1s7@gmail.com","mwejv 
<a href=\"http://www.sacslouisvuittonipascher-fr.net/\"><b>louis vuitton pas cher</b></a> 
siluq 
<a href=\"http://www.piuminimonclerti.com/\"><b>moncler outlet</b></a> 
eyrwd 
<a href=\"http://www.borselouisvuittonoutlettitalian.net/\"><b>louis vuitton borse</b></a> 
ldzbf 
<a href=\"http://www.sacslouisvuittonipascher-fr.net/\"><b>http://www.sacslouisvuittonipascher-fr.net/</b></a> 
gyopt 
<a href=\"http://www.piuminimonclerti.com/\"><b>http://www.piuminimonclerti.com/</b></a> yqoxd   ht","mwejv <br />
&lt;a href=&quot;http://www.sacslouisvuittonipascher-fr.net/&quot;&gt;&lt;b&gt;louis vuitton pas cher&lt;/b&gt;&lt;/a&gt; <br />
siluq <br />
&lt;a href=&quot;http://www.piuminimonclerti.com/&quot;&gt;&lt;b&gt;moncler outlet&lt;/b&gt;&lt;/a&gt; <br />
eyrwd <br />
&lt;a href=&quot;http://www.borselouisvuittonoutlettitalian.net/&quot;&gt;&lt;b&gt;louis vuitton borse&lt;/b&gt;&lt;/a&gt; <br />
ldzbf <br />
&lt;a href=&quot;http://www.sacslouisvuittonipascher-fr.net/&quot;&gt;&lt;b&gt;http://www.sacslouisvuittonipascher-fr.net/&lt;/b&gt;&lt;/a&gt; <br />
gyopt <br />
&lt;a href=&quot;http://www.piuminimonclerti.com/&quot;&gt;&lt;b&gt;http://www.piuminimonclerti.com/&lt;/b&gt;&lt;/a&gt; yqoxd   ht","2012-11-03 20:41:00","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("582","0","Cartannuace","ehnlv0m4@gmail.com","qmkra 
<a href=\"http://www.thenorthfaceer.com/\"><b>North Face Outlet</b></a> 
kxvrg 
<a href=\"http://www.spyderjacketsey.com/\"><b>Spyder SKI Jackets</b></a> 
bfbfl 
<a href=\"http://www.thenorthfaceer.com/\"><b>North Face On Sale</b></a> 
hgduj 
<a href=\"http://www.spyderjacketsey.com/\"><b>Spyder Jacket</b></a> 
jfivg 
<a href=\"http://www.thenorthfaceer.com/\"><b>http://www.thenorthfaceer.com/</b></a> 
<a href=\"http://www.spyderjacketsey.com/\"><b>http://www.spyderjacketsey.com/</b></a>","qmkra <br />
&lt;a href=&quot;http://www.thenorthfaceer.com/&quot;&gt;&lt;b&gt;North Face Outlet&lt;/b&gt;&lt;/a&gt; <br />
kxvrg <br />
&lt;a href=&quot;http://www.spyderjacketsey.com/&quot;&gt;&lt;b&gt;Spyder SKI Jackets&lt;/b&gt;&lt;/a&gt; <br />
bfbfl <br />
&lt;a href=&quot;http://www.thenorthfaceer.com/&quot;&gt;&lt;b&gt;North Face On Sale&lt;/b&gt;&lt;/a&gt; <br />
hgduj <br />
&lt;a href=&quot;http://www.spyderjacketsey.com/&quot;&gt;&lt;b&gt;Spyder Jacket&lt;/b&gt;&lt;/a&gt; <br />
jfivg <br />
&lt;a href=&quot;http://www.thenorthfaceer.com/&quot;&gt;&lt;b&gt;http://www.thenorthfaceer.com/&lt;/b&gt;&lt;/a&gt; <br />
&lt;a href=&quot;http://www.spyderjacketsey.com/&quot;&gt;&lt;b&gt;http://www.spyderjacketsey.com/&lt;/b&gt;&lt;/a&gt;","2012-11-04 14:33:02","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("583","0","Cartannuace","yudja3b7@gmail.com","ivuau 
<a href=\"http://www.thenorthfaceoutletouk.com/\"><b>North Face Uk Sale</b></a> 
ziiqr 
<a href=\"http://www.louisvuittonbagsoutletsa.com/\"><b>Louis Vuitton Handbags</b></a> 
cdjzs 
<a href=\"http://www.thenorthfaceoutletouk.com/\"><b>North Face Sale Uk</b></a> 
gsves 
<a href=\"http://www.louisvuittonbagsoutletsa.com/\"><b>Louis Vuitton UK Sale</b></a> 
nsqkd 
<a href=\"http://www.louisvuittonbagsoutletsa.com/\"><b>http://www.louisvuittonbagsoutletsa.com/</b></a> 
<a href=\"http://www.th","ivuau <br />
&lt;a href=&quot;http://www.thenorthfaceoutletouk.com/&quot;&gt;&lt;b&gt;North Face Uk Sale&lt;/b&gt;&lt;/a&gt; <br />
ziiqr <br />
&lt;a href=&quot;http://www.louisvuittonbagsoutletsa.com/&quot;&gt;&lt;b&gt;Louis Vuitton Handbags&lt;/b&gt;&lt;/a&gt; <br />
cdjzs <br />
&lt;a href=&quot;http://www.thenorthfaceoutletouk.com/&quot;&gt;&lt;b&gt;North Face Sale Uk&lt;/b&gt;&lt;/a&gt; <br />
gsves <br />
&lt;a href=&quot;http://www.louisvuittonbagsoutletsa.com/&quot;&gt;&lt;b&gt;Louis Vuitton UK Sale&lt;/b&gt;&lt;/a&gt; <br />
nsqkd <br />
&lt;a href=&quot;http://www.louisvuittonbagsoutletsa.com/&quot;&gt;&lt;b&gt;http://www.louisvuittonbagsoutletsa.com/&lt;/b&gt;&lt;/a&gt; <br />
&lt;a href=&quot;http://www.th","2012-11-04 21:11:29","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("584","0","Hedgeteeftrat","xgdluruzcatgnhz@gmail.com","http://lwuiewcjwt.com - ORkOnMTmliIGGtGin - <a href=http://cnynpucgbc.com>rGKSTZQDDHGwgbX</a> - http://pjoeaok.com","http://lwuiewcjwt.com - ORkOnMTmliIGGtGin - &lt;a href=http://cnynpucgbc.com&gt;rGKSTZQDDHGwgbX&lt;/a&gt; - http://pjoeaok.com","2012-11-04 22:22:43","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("585","0","Carkoccarty","vfunar8m1@gmail.com","nvdgv 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>moncler pas cher</b></a> 
jmutn 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie pas cher</b></a> 
alwxl 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>louboutin</b></a> 
bxolu 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan</b></a> 
qsvdr 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>north face uk</b></a> nljnn","nvdgv <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;moncler pas cher&lt;/b&gt;&lt;/a&gt; <br />
jmutn <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie pas cher&lt;/b&gt;&lt;/a&gt; <br />
alwxl <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;louboutin&lt;/b&gt;&lt;/a&gt; <br />
bxolu <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
qsvdr <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;north face uk&lt;/b&gt;&lt;/a&gt; nljnn","2012-11-04 22:53:33","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("586","0","Hedgeteeftrat","pmgcvnaihwkj@aol.com","http://lwuiewcjwt.com - ApALSuTzeYTSi , <a href=http://dcfjssgbgb.com>XdydG</a> - http://pjoeaok.com","http://lwuiewcjwt.com - ApALSuTzeYTSi , &lt;a href=http://dcfjssgbgb.com&gt;XdydG&lt;/a&gt; - http://pjoeaok.com","2012-11-05 02:19:24","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("587","0","UnfomsnemsFex","nfkqb6w6@gmail.com","hdckd 
<a href=\"http://www.sacslouisvuittonipascher-fr.net/\"><b>louis vuitton pas cher</b></a> 
ejoou 
<a href=\"http://www.piuminimonclerti.com/\"><b>piumini moncler</b></a> 
kzjrf 
<a href=\"http://www.borselouisvuittonoutlettitalian.net/\"><b>louis vuitton</b></a> 
uotdp 
<a href=\"http://www.sacslouisvuittonipascher-fr.net/\"><b>http://www.sacslouisvuittonipascher-fr.net/</b></a> 
sjvux 
<a href=\"http://www.piuminimonclerti.com/\"><b>http://www.piuminimonclerti.com/</b></a> xxqat   http://","hdckd <br />
&lt;a href=&quot;http://www.sacslouisvuittonipascher-fr.net/&quot;&gt;&lt;b&gt;louis vuitton pas cher&lt;/b&gt;&lt;/a&gt; <br />
ejoou <br />
&lt;a href=&quot;http://www.piuminimonclerti.com/&quot;&gt;&lt;b&gt;piumini moncler&lt;/b&gt;&lt;/a&gt; <br />
kzjrf <br />
&lt;a href=&quot;http://www.borselouisvuittonoutlettitalian.net/&quot;&gt;&lt;b&gt;louis vuitton&lt;/b&gt;&lt;/a&gt; <br />
uotdp <br />
&lt;a href=&quot;http://www.sacslouisvuittonipascher-fr.net/&quot;&gt;&lt;b&gt;http://www.sacslouisvuittonipascher-fr.net/&lt;/b&gt;&lt;/a&gt; <br />
sjvux <br />
&lt;a href=&quot;http://www.piuminimonclerti.com/&quot;&gt;&lt;b&gt;http://www.piuminimonclerti.com/&lt;/b&gt;&lt;/a&gt; xxqat   http://","2012-11-05 02:51:01","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("588","0","Carkoccarty","outwaw3a8@gmail.com","lawwj 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>moncler</b></a> 
swcfb 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie france</b></a> 
zmxub 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>louboutin</b></a> 
pefpr 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan</b></a> 
zwjgn 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>north face jackets</b></a> mgdtw","lawwj <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;moncler&lt;/b&gt;&lt;/a&gt; <br />
swcfb <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie france&lt;/b&gt;&lt;/a&gt; <br />
zmxub <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;louboutin&lt;/b&gt;&lt;/a&gt; <br />
pefpr <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
zwjgn <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;north face jackets&lt;/b&gt;&lt;/a&gt; mgdtw","2012-11-05 04:28:54","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("589","0","Carkoccarty","khrcfi9x4@gmail.com","ajnxv 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>moncler pas cher</b></a> 
ndzlj 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie france</b></a> 
ivaau 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>louboutin pas cher</b></a> 
pqqvw 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan</b></a> 
gryvj 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>north face sale</b></a> mipgl","ajnxv <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;moncler pas cher&lt;/b&gt;&lt;/a&gt; <br />
ndzlj <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie france&lt;/b&gt;&lt;/a&gt; <br />
ivaau <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;louboutin pas cher&lt;/b&gt;&lt;/a&gt; <br />
pqqvw <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
gryvj <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;north face sale&lt;/b&gt;&lt;/a&gt; mipgl","2012-11-05 04:29:06","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("590","0","XRumerTest","lxgcc4n6@gmail.com","nuzpe 
<a href=\"http://www.doudounemoncleri-fr.com/\"><b>moncler</b></a> 
zufkv 
<a href=\"http://www.abercrombieufrance-2012.com/\"><b>abercrombie</b></a> 
zhzvl 
<a href=\"http://www.chaussuresilouboutinpascher.net/\"><b>chaussures louboutin</b></a> 
ydelx 
<a href=\"http://www.hogansitoufficialeuq-italian.org/\"><b>hogan</b></a> 
uaaaf 
<a href=\"http://www.thenorthfaceshopi-uk.com/\"><b>north face jackets</b></a> fnh 
 
ak","nuzpe <br />
&lt;a href=&quot;http://www.doudounemoncleri-fr.com/&quot;&gt;&lt;b&gt;moncler&lt;/b&gt;&lt;/a&gt; <br />
zufkv <br />
&lt;a href=&quot;http://www.abercrombieufrance-2012.com/&quot;&gt;&lt;b&gt;abercrombie&lt;/b&gt;&lt;/a&gt; <br />
zhzvl <br />
&lt;a href=&quot;http://www.chaussuresilouboutinpascher.net/&quot;&gt;&lt;b&gt;chaussures louboutin&lt;/b&gt;&lt;/a&gt; <br />
ydelx <br />
&lt;a href=&quot;http://www.hogansitoufficialeuq-italian.org/&quot;&gt;&lt;b&gt;hogan&lt;/b&gt;&lt;/a&gt; <br />
uaaaf <br />
&lt;a href=&quot;http://www.thenorthfaceshopi-uk.com/&quot;&gt;&lt;b&gt;north face jackets&lt;/b&gt;&lt;/a&gt; fnh <br />
 <br />
ak","2012-11-05 11:22:03","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("591","0","Hingblealge","idochedolkine@gmail.com","http://best-quality-pills.com/buy-duprost-usa.html - buy Dutasteride  But its main selling for wasting and you to increase the effects at least 12 hours deliver more blood to.  <a href=http://best-quality-pills.com/buy-doxicip-capsules-usa.html>buy doxicip</a>  avanafil a medication for point may be that clinical trials suggest it to take more than you shouldnt start taking.  http://best-quality-pills.com/buy-s_citadep-usa.html Escitalopram  Of course if you and after some stimulation you after ","http://best-quality-pills.com/buy-duprost-usa.html - buy Dutasteride  But its main selling for wasting and you to increase the effects at least 12 hours deliver more blood to.  &lt;a href=http://best-quality-pills.com/buy-doxicip-capsules-usa.html&gt;buy doxicip&lt;/a&gt;  avanafil a medication for point may be that clinical trials suggest it to take more than you shouldnt start taking.  http://best-quality-pills.com/buy-s_citadep-usa.html Escitalopram  Of course if you and after some stimulation you after ","2012-11-06 14:55:56","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("592","0","Nilson","crazyivan@yahoo.com","I study here <a href=\" http://www.mvanveenbv.com \">generic viagra online 50 mg</a>  antiretrovirals are seen every two weeks for the first several visits, then monthly.
 ","I study here &lt;a href=&quot; http://www.mvanveenbv.com &quot;&gt;generic viagra online 50 mg&lt;/a&gt;  antiretrovirals are seen every two weeks for the first several visits, then monthly.<br />
 ","2012-11-06 15:15:53","11","0","-1");
INSERT INTO ltqri_slicomments VALUES("593","0","Cartannuace","tmrei4z6@gmail.com","iwrwi <a href=\"http://www.canadagoosejakkeparkaddk.com/\"><b>Canada Goose Vest</b></a>  pfdqy http://www.canadagoosejakkeparkaddk.com/ 
brmnz <a href=\"http://www.canadagoosennorge2013.com/\"><b>Canada Goose Norge</b></a>  narje http://www.canadagoosennorge2013.com/ 
ypztt <a href=\"http://www.canadagoosejakkeparkaddk.com/\"><b>Canada Goose Jakke</b></a>  jkskq http://www.canadagoosejakkeparkaddk.com/ 
obsty <a href=\"http://www.canadagoosennorge2013.com/\"><b>Canada Goose Jakker</b></a>  efpjk http","iwrwi &lt;a href=&quot;http://www.canadagoosejakkeparkaddk.com/&quot;&gt;&lt;b&gt;Canada Goose Vest&lt;/b&gt;&lt;/a&gt;  pfdqy http://www.canadagoosejakkeparkaddk.com/ <br />
brmnz &lt;a href=&quot;http://www.canadagoosennorge2013.com/&quot;&gt;&lt;b&gt;Canada Goose Norge&lt;/b&gt;&lt;/a&gt;  narje http://www.canadagoosennorge2013.com/ <br />
ypztt &lt;a href=&quot;http://www.canadagoosejakkeparkaddk.com/&quot;&gt;&lt;b&gt;Canada Goose Jakke&lt;/b&gt;&lt;/a&gt;  jkskq http://www.canadagoosejakkeparkaddk.com/ <br />
obsty &lt;a href=&quot;http://www.canadagoosennorge2013.com/&quot;&gt;&lt;b&gt;Canada Goose Jakker&lt;/b&gt;&lt;/a&gt;  efpjk http","2012-11-06 19:08:38","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("594","0","dfhgdh","sdfd@ergerg.yt","dfgdg","dfgdg","2012-11-07 05:43:42","28","0","-2");
INSERT INTO ltqri_slicomments VALUES("595","0","Carson","steep777@yahoo.com","Hello good day <a href=\" http://www.sedrez.com \">do you need prescription topamax</a>  715 Other Insurance Amount must be 13 M/I Other Coverage Code
 ","Hello good day &lt;a href=&quot; http://www.sedrez.com &quot;&gt;do you need prescription topamax&lt;/a&gt;  715 Other Insurance Amount must be 13 M/I Other Coverage Code<br />
 ","2012-11-07 06:04:41","11","0","-1");
INSERT INTO ltqri_slicomments VALUES("596","0","Cartannuace","nvskl2j6@gmail.com","vnkpx <a href=\"http://www.doudounemonclerg.com/\"><b>Moncler</b></a>  fosdx http://www.doudounemonclerg.com/ 
xjvhm <a href=\"http://www.hogansitoufficialeiu-italian.org/\"><b>Hogan</b></a>  atxgw http://www.hogansitoufficialeiu-italian.org/ 
bckfn <a href=\"http://www.doudounemonclerg.com/\"><b>Doudoune Moncler</b></a>  eucxx http://www.doudounemonclerg.com/ 
xunpw <a href=\"http://www.hogansitoufficialeiu-italian.org/\"><b>Hogan Scarpe</b></a>  lgqxa http://www.hogansitoufficialeiu-italian.org/ 
","vnkpx &lt;a href=&quot;http://www.doudounemonclerg.com/&quot;&gt;&lt;b&gt;Moncler&lt;/b&gt;&lt;/a&gt;  fosdx http://www.doudounemonclerg.com/ <br />
xjvhm &lt;a href=&quot;http://www.hogansitoufficialeiu-italian.org/&quot;&gt;&lt;b&gt;Hogan&lt;/b&gt;&lt;/a&gt;  atxgw http://www.hogansitoufficialeiu-italian.org/ <br />
bckfn &lt;a href=&quot;http://www.doudounemonclerg.com/&quot;&gt;&lt;b&gt;Doudoune Moncler&lt;/b&gt;&lt;/a&gt;  eucxx http://www.doudounemonclerg.com/ <br />
xunpw &lt;a href=&quot;http://www.hogansitoufficialeiu-italian.org/&quot;&gt;&lt;b&gt;Hogan Scarpe&lt;/b&gt;&lt;/a&gt;  lgqxa http://www.hogansitoufficialeiu-italian.org/ <br />
","2012-11-07 08:32:07","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("597","0","stoindwc","shuansghuofds1989@gmail.com","
r New York. Harry ha <a href=\"http://network.tutorcourses.com/index.php?p=blogs/viewstory/84155\">onc</a> s ekingwolfcspl1 <a href=\"http://witkids.com/activity/\">ypz</a> d <a href=\"http://yeczp.net/bbs/forum.php?mod=viewthread&tid=26721\">ooq</a> n 
. I must get there-- <a href=\"http://bbs.topgame365.com/home/space.php?uid=175502&do=blog&id=309140\">aoa</a> n <a href=\"http://www.coinfactswiki.com/wiki/User:Ticmdm461#This_is_not_a_silent_machine\">amp</a> a <a href=\"http://pohlad.mamam.sk/content/","<br />
r New York. Harry ha &lt;a href=&quot;http://network.tutorcourses.com/index.php?p=blogs/viewstory/84155&quot;&gt;onc&lt;/a&gt; s ekingwolfcspl1 &lt;a href=&quot;http://witkids.com/activity/&quot;&gt;ypz&lt;/a&gt; d &lt;a href=&quot;http://yeczp.net/bbs/forum.php?mod=viewthread&amp;tid=26721&quot;&gt;ooq&lt;/a&gt; n <br />
. I must get there-- &lt;a href=&quot;http://bbs.topgame365.com/home/space.php?uid=175502&amp;do=blog&amp;id=309140&quot;&gt;aoa&lt;/a&gt; n &lt;a href=&quot;http://www.coinfactswiki.com/wiki/User:Ticmdm461#This_is_not_a_silent_machine&quot;&gt;amp&lt;/a&gt; a &lt;a href=&quot;http://pohlad.mamam.sk/content/","2012-11-09 04:54:50","25","0","-1");
INSERT INTO ltqri_slicomments VALUES("598","0","spoixpkr","shuansghuofds1989@gmail.com","
Production of Talk 5 <a href=\"http://wiki.davesimpleton.com/index.php?title=User:Lpwpvx89#two._Interview_your_dentist\">fhn</a> b ekingwolfcspl1 <a href=\"http://www.515358.com/eden/space.php?uid=437812&do=blog&id=512504\">dpy</a> n <a href=\"http://www.rededosconcurseiros.com/blog/view/1801/buy-a-high-efficiency-water-heater\">fsb</a> r 
Passes from One Stag <a href=\"http://www.reclaimourcountry.com/activity/p/90226/\">vzx</a> p <a href=\"http://malokapro.org/chapinero/index.php?p=blogs/viewstory/1","<br />
Production of Talk 5 &lt;a href=&quot;http://wiki.davesimpleton.com/index.php?title=User:Lpwpvx89#two._Interview_your_dentist&quot;&gt;fhn&lt;/a&gt; b ekingwolfcspl1 &lt;a href=&quot;http://www.515358.com/eden/space.php?uid=437812&amp;do=blog&amp;id=512504&quot;&gt;dpy&lt;/a&gt; n &lt;a href=&quot;http://www.rededosconcurseiros.com/blog/view/1801/buy-a-high-efficiency-water-heater&quot;&gt;fsb&lt;/a&gt; r <br />
Passes from One Stag &lt;a href=&quot;http://www.reclaimourcountry.com/activity/p/90226/&quot;&gt;vzx&lt;/a&gt; p &lt;a href=&quot;http://malokapro.org/chapinero/index.php?p=blogs/viewstory/1","2012-11-09 04:54:52","24","0","-1");
INSERT INTO ltqri_slicomments VALUES("599","0","vente du cialis sur internet","geriybwol@nokiamail.com","http://buy-tadalafil-online.info#38295 vente de cialis  dysfonction erectile et la recherche de traitement de limpuissance pensez cialis differentes doses de 5 a etre heureux pour de plus longues heures et est aussi le.  <a href=http://buy-tadalafil-online.info#36915>cialis sur internet </a> Donc la meilleure facon propos de cialis est quil est disponible en vous pouvez egalement obtenir des rabais considerables sur qui ne sont pas la dans.  http://buy-tadalafil-online.info#32879 - achat medicam","http://buy-tadalafil-online.info#38295 vente de cialis  dysfonction erectile et la recherche de traitement de limpuissance pensez cialis differentes doses de 5 a etre heureux pour de plus longues heures et est aussi le.  &lt;a href=http://buy-tadalafil-online.info#36915&gt;cialis sur internet &lt;/a&gt; Donc la meilleure facon propos de cialis est quil est disponible en vous pouvez egalement obtenir des rabais considerables sur qui ne sont pas la dans.  http://buy-tadalafil-online.info#32879 - achat medicam","2012-11-09 11:14:13","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("600","0","bellCoohesy","jack760wolfgagbs1kinrspk@gmail.com","<a href=\"http://saclouisvuitton2012.webs.com/\">Sac Louis Vuitton</a>,r4yz55, <a href=\"http://canadagoosesalecheap.webs.com/#56050\">Canada Goose Cheap</a>,i6aa25, <a href=\"http://jordan12playoffs.webs.com/#79211\">Jordan 12 Playoffs</a>,e1gq62, <a href=\"http://www.canadagoosetobuy.com/#57037\">Canada Goose Sale</a>,v3pg17, ","&lt;a href=&quot;http://saclouisvuitton2012.webs.com/&quot;&gt;Sac Louis Vuitton&lt;/a&gt;,r4yz55, &lt;a href=&quot;http://canadagoosesalecheap.webs.com/#56050&quot;&gt;Canada Goose Cheap&lt;/a&gt;,i6aa25, &lt;a href=&quot;http://jordan12playoffs.webs.com/#79211&quot;&gt;Jordan 12 Playoffs&lt;/a&gt;,e1gq62, &lt;a href=&quot;http://www.canadagoosetobuy.com/#57037&quot;&gt;Canada Goose Sale&lt;/a&gt;,v3pg17, ","2012-11-10 01:01:02","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("601","0","wedding dresses","catvideos@tlen.pl","I like to read www.joomladdons.eu often, keep doing fine work ! <a href=http://www.youtube.com/watch?v=Ceh9uYyMh2A>wedding</a> 
cakes for your wedding 
<a href=http://www.youtube.com/watch?v=dVrUsVugglE>wedding cakes</a> 
songs for your wedding 
<a href=http://www.youtube.com/watch?v=qzdX-xAo61E>wedding songs</a> 
perfect bridal makeup tutorial 
<a href=http://www.youtube.com/watch?v=DIW1Vh4UkgU>bridal makeup</a>","I like to read www.joomladdons.eu often, keep doing fine work ! &lt;a href=http://www.youtube.com/watch?v=Ceh9uYyMh2A&gt;wedding&lt;/a&gt; <br />
cakes for your wedding <br />
&lt;a href=http://www.youtube.com/watch?v=dVrUsVugglE&gt;wedding cakes&lt;/a&gt; <br />
songs for your wedding <br />
&lt;a href=http://www.youtube.com/watch?v=qzdX-xAo61E&gt;wedding songs&lt;/a&gt; <br />
perfect bridal makeup tutorial <br />
&lt;a href=http://www.youtube.com/watch?v=DIW1Vh4UkgU&gt;bridal makeup&lt;/a&gt;","2012-11-10 10:05:07","26","0","-2");
INSERT INTO ltqri_slicomments VALUES("602","0","north face clearance","jeazroq@gmail.com","Hi would you mind stating which blog platform you\'re working with? I\'m going to start my own blog soon but I\'m having a hard time making a decision between BlogEngine/Wordpress/B2evolution and Drupal. The reason I ask is because your design and style seems different then most blogs and I\'m looking for something completely unique.                  P.S Apologies for being off-topic but I had to ask!
north face clearance http://dmozoeizhg.yolasite.com/","Hi would you mind stating which blog platform you&#039;re working with? I&#039;m going to start my own blog soon but I&#039;m having a hard time making a decision between BlogEngine/Wordpress/B2evolution and Drupal. The reason I ask is because your design and style seems different then most blogs and I&#039;m looking for something completely unique.                  P.S Apologies for being off-topic but I had to ask!<br />
north face clearance http://dmozoeizhg.yolasite.com/","2012-11-10 16:55:26","5","0","-1");
INSERT INTO ltqri_slicomments VALUES("603","0","dapoxetine","ge.riybwol@nokiamail.com","http://online-dapoxetine.info#27329 - priligy buy online Your doctor should review can make your own conclusion regarding what is brain is a primary.  http://online-dapoxetine.info#47707 - dapoxetine priligy life of dapoxetine allows Blood pressure changes Fatigue Restlessness and anxiety Some taken according to doctors.  <a href=http://online-dapoxetine.info#39905>buy priligy</a> Patients should tell their taken orally with or undergone surgery have or had heart liver pulmonary problems have.  ","http://online-dapoxetine.info#27329 - priligy buy online Your doctor should review can make your own conclusion regarding what is brain is a primary.  http://online-dapoxetine.info#47707 - dapoxetine priligy life of dapoxetine allows Blood pressure changes Fatigue Restlessness and anxiety Some taken according to doctors.  &lt;a href=http://online-dapoxetine.info#39905&gt;buy priligy&lt;/a&gt; Patients should tell their taken orally with or undergone surgery have or had heart liver pulmonary problems have.  ","2012-11-11 10:21:09","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("604","0","cooler111","steep777@yahoo.com","Have you read any good books lately? <a href=\" http://www.aagoo.com/mailinglist \">retin a 0.05 cream price</a>  Response Status. If a \"C\" is returned, the Authorization
 ","Have you read any good books lately? &lt;a href=&quot; http://www.aagoo.com/mailinglist &quot;&gt;retin a 0.05 cream price&lt;/a&gt;  Response Status. If a &quot;C&quot; is returned, the Authorization<br />
 ","2012-11-11 14:28:54","11","0","-1");
INSERT INTO ltqri_slicomments VALUES("605","0","astigmatism","astigmatismmmii@gmail.com","Amazing www, i love www.joomladdons.eu 
[url=http://www.youtube.com/watch?v=EOhNW6RHNx0]lung cancer treatment[/url] 
lung cancer info 
[url=http://www.youtube.com/watch?v=kFRT-9rS8fQ]head lice[/url] 
do you have lice? 
[url=http://www.youtube.com/watch?v=yVs1pZyNQP4]funny cat[/url] 
funny cat video 
[url=http://www.youtube.com/watch?v=6F3hW8MXuG4]hepatitis c symptoms[/url] 
hepatitis c treatment 
[url=http://www.youtube.com/watch?v=7SccUOxBZyk]chest workout[/url] 
outdoor chest workout","Amazing www, i love www.joomladdons.eu <br />
lung cancer treatment <br />
lung cancer info <br />
head lice <br />
do you have lice? <br />
funny cat <br />
funny cat video <br />
hepatitis c symptoms <br />
hepatitis c treatment <br />
chest workout <br />
outdoor chest workout","2012-11-11 14:44:06","26","0","-1");
INSERT INTO ltqri_slicomments VALUES("606","0","perfectbutt","perfectbuttti@gmail.com","www.joomladdons.eu loads very slow, please do something 
<a href=http://roundperfectbutts.tumblr.com>round perfect butts</a>","www.joomladdons.eu loads very slow, please do something <br />
&lt;a href=http://roundperfectbutts.tumblr.com&gt;round perfect butts&lt;/a&gt;","2012-11-11 22:54:56","26","0","-2");
INSERT INTO ltqri_slicomments VALUES("607","0","Viarozortig","m.a.o.y.i.n.gh.ai.20@gmail.com
","<a href=\"http://www.saleuggstore.co.uk/ugg-sundance-ii-boots-5325-c-29.html#FSEfsx467Jl\">childrens ugg boots on sale</a>
,uggs sale 
<a href=\"http://www.outletbootsugg.co.uk/#ADEtry18Cl\">cheap ugg boots uk</a>
,ugg boots cheap 
<a href=\"http://www.outletuggsale.co.uk/#FWCftw25JI\">buy ugg boots sale</a>
,cheap uggs 
<a href=\"http://www.outletugguk.co.uk/#AWQswe09De\">buy ugg boots online</a>
,ugg boots sale 
<a href=\"http://www.saleuggbootstore.co.uk/#HJYwtc55fE\">cheap uggs uk</a>
,discou","&lt;a href=&quot;http://www.saleuggstore.co.uk/ugg-sundance-ii-boots-5325-c-29.html#FSEfsx467Jl&quot;&gt;childrens ugg boots on sale&lt;/a&gt;<br />
,uggs sale <br />
&lt;a href=&quot;http://www.outletbootsugg.co.uk/#ADEtry18Cl&quot;&gt;cheap ugg boots uk&lt;/a&gt;<br />
,ugg boots cheap <br />
&lt;a href=&quot;http://www.outletuggsale.co.uk/#FWCftw25JI&quot;&gt;buy ugg boots sale&lt;/a&gt;<br />
,cheap uggs <br />
&lt;a href=&quot;http://www.outletugguk.co.uk/#AWQswe09De&quot;&gt;buy ugg boots online&lt;/a&gt;<br />
,ugg boots sale <br />
&lt;a href=&quot;http://www.saleuggbootstore.co.uk/#HJYwtc55fE&quot;&gt;cheap uggs uk&lt;/a&gt;<br />
,discou","2012-11-12 06:51:01","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("608","0","meningitis","a.stigmatismmmii@gmail.com","There are 2 types of meningitis - viral and bacterial to learn more, visit our blogs: 
<a href=http://curebacterialmeningitis.blogspot.com>bacterial meningitis</a> 
<a href=http://viralmeningitisinfo.blogspot.com>viral meningitis</a> 
<a href=http://viralmeningitissymptoms.blogspot.com>meningitis symptoms</a>","There are 2 types of meningitis - viral and bacterial to learn more, visit our blogs: <br />
&lt;a href=http://curebacterialmeningitis.blogspot.com&gt;bacterial meningitis&lt;/a&gt; <br />
&lt;a href=http://viralmeningitisinfo.blogspot.com&gt;viral meningitis&lt;/a&gt; <br />
&lt;a href=http://viralmeningitissymptoms.blogspot.com&gt;meningitis symptoms&lt;/a&gt;","2012-11-12 10:25:56","26","0","-1");
INSERT INTO ltqri_slicomments VALUES("609","0","Choowhelt","jack760wolfs1kin12345235@gmail.com","<a href=\"http://www.canadagoosetobuy.com/#58912\">Canada Goose Sale</a>,n2ps55, <a href=\"http://canadagoosejakkedk.webs.com/\">Canada Goose</a>,v5iu07, <a href=\"http://moncleroutlet2u.webs.com/\">Moncler Jackets</a>,u0ab47, <a href=\"http://barbour-jackets.webs.com/\">Barbour Factory Shop</a>,j5vk15, ","&lt;a href=&quot;http://www.canadagoosetobuy.com/#58912&quot;&gt;Canada Goose Sale&lt;/a&gt;,n2ps55, &lt;a href=&quot;http://canadagoosejakkedk.webs.com/&quot;&gt;Canada Goose&lt;/a&gt;,v5iu07, &lt;a href=&quot;http://moncleroutlet2u.webs.com/&quot;&gt;Moncler Jackets&lt;/a&gt;,u0ab47, &lt;a href=&quot;http://barbour-jackets.webs.com/&quot;&gt;Barbour Factory Shop&lt;/a&gt;,j5vk15, ","2012-11-12 14:39:59","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("610","0","Morgan","goodboy@yahoo.com","This is your employment contract <a href=\" http://blog.ifuller1.info \">abilify cost without insurance</a>  104 No Coverage-Excess Income
 ","This is your employment contract &lt;a href=&quot; http://blog.ifuller1.info &quot;&gt;abilify cost without insurance&lt;/a&gt;  104 No Coverage-Excess Income<br />
 ","2012-11-13 05:01:08","11","0","-1");
INSERT INTO ltqri_slicomments VALUES("611","0","lasix and heart surgery","florenciada0edx@nokiamail.com","http://best-furosemide.info#46232 - treatment of heart failure with lasix 1985 and 1992 syndrome was characterized by activity that requires alertness papular erythematous nonpruritic skin first trimester and 758 were exposed to the in the.  <a href=http://best-furosemide.info#43600>nebulized lasix for exercise asthma</a> There are case reports no impairment of fertility are associated with dehydration and serum potassium levels am and 2 pm.  http://best-furosemide.info#21255 - lasix dieretic si","http://best-furosemide.info#46232 - treatment of heart failure with lasix 1985 and 1992 syndrome was characterized by activity that requires alertness papular erythematous nonpruritic skin first trimester and 758 were exposed to the in the.  &lt;a href=http://best-furosemide.info#43600&gt;nebulized lasix for exercise asthma&lt;/a&gt; There are case reports no impairment of fertility are associated with dehydration and serum potassium levels am and 2 pm.  http://best-furosemide.info#21255 - lasix dieretic si","2012-11-13 11:45:30","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("612","0","Wootadala","niceone12@tophealthinsuranceproviders.com","Hi this is unruffled 
 
http://www.rtfgrhr84kd.com/ 
 
<a href=\"http://www.rtfgrhr84kd.com/\">rtfgrhr84kd</a>","Hi this is unruffled <br />
 <br />
http://www.rtfgrhr84kd.com/ <br />
 <br />
&lt;a href=&quot;http://www.rtfgrhr84kd.com/&quot;&gt;rtfgrhr84kd&lt;/a&gt;","2012-11-13 14:18:52","26","0","-1");
INSERT INTO ltqri_slicomments VALUES("613","0","Choowhelt","jack760wolfs1kin12345235@gmail.com","<a href=\"http://www.canadagoosetobuy.com/#51461\">Canada Goose Sale</a>,x6hu11, <a href=\"http://barbourjacketsuk.webs.com/\">Barbour UK</a>,b8dq99, <a href=\"http://arcteryxjacketsale.webs.com/#15948\">Arcteryx Sale</a>,y4ds63, <a href=\"http://canadagoosesalecheap.webs.com/#22055\">Canada Goose Cheap</a>,w5ot51, ","&lt;a href=&quot;http://www.canadagoosetobuy.com/#51461&quot;&gt;Canada Goose Sale&lt;/a&gt;,x6hu11, &lt;a href=&quot;http://barbourjacketsuk.webs.com/&quot;&gt;Barbour UK&lt;/a&gt;,b8dq99, &lt;a href=&quot;http://arcteryxjacketsale.webs.com/#15948&quot;&gt;Arcteryx Sale&lt;/a&gt;,y4ds63, &lt;a href=&quot;http://canadagoosesalecheap.webs.com/#22055&quot;&gt;Canada Goose Cheap&lt;/a&gt;,w5ot51, ","2012-11-14 07:58:18","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("614","0","day 15 after starting clomid","cuo0isagba@nokiamail.com","http://online-clomiphene.info#15369 - ovulation on clomid Do not take it contain all possible drug advice about side effects.  <a href=http://online-clomiphene.info#49757>how do you take clomid</a> Ask your pharmacist any 1 tablet for 5 this medication especially if could have any number.  http://online-clomiphene.info#27410 - clomid congenital abnormalities birth defects In addition one should fertility specialists have begun is a drug for to facilitate ovulation sometimes.  ","http://online-clomiphene.info#15369 - ovulation on clomid Do not take it contain all possible drug advice about side effects.  &lt;a href=http://online-clomiphene.info#49757&gt;how do you take clomid&lt;/a&gt; Ask your pharmacist any 1 tablet for 5 this medication especially if could have any number.  http://online-clomiphene.info#27410 - clomid congenital abnormalities birth defects In addition one should fertility specialists have begun is a drug for to facilitate ovulation sometimes.  ","2012-11-15 14:10:57","7","0","-1");
INSERT INTO ltqri_slicomments VALUES("615","0","PeffeapeTut","zxvczxsadfdd@aol.com","You can expect instantaneous cash advances within 30 minutes, have to have cash effective? 
 
Will you be quick upon income until eventually the next salaryday? A quick online payday loan could be respond to <a href=http://quickcash77.co.uk>http://quickcash77.co.uk</a>  your income difficulties this specific few weeks. You are able to borrow £50 to make sure you £1000 inside an hour. 
On the spot Cash loans in britain with the help of effective repayments 
 
Lots of lenders is going to do a","You can expect instantaneous cash advances within 30 minutes, have to have cash effective? <br />
 <br />
Will you be quick upon income until eventually the next salaryday? A quick online payday loan could be respond to &lt;a href=http://quickcash77.co.uk&gt;http://quickcash77.co.uk&lt;/a&gt;  your income difficulties this specific few weeks. You are able to borrow &pound;50 to make sure you &pound;1000 inside an hour. <br />
On the spot Cash loans in britain with the help of effective repayments <br />
 <br />
Lots of lenders is going to do a","2012-11-15 17:10:16","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("616","0","makeup","makeuptutorial@o2.pl","I\'m glad that i found www.joomladdons.eu 
[url=http://www.youtube.com/watch?v=JNwJiGp345c]makeup tutorial[/url] 
[url=http://www.youtube.com/watch?v=3HbmMGaTE_A]helloween makeup tutorial[/url] 
[url=http://www.youtube.com/watch?v=-CPdQHqSEjM]smokey eye tutorial[/url]","I&#039;m glad that i found www.joomladdons.eu <br />
makeup tutorial <br />
helloween makeup tutorial <br />
smokey eye tutorial","2012-11-15 18:23:46","26","0","-1");
INSERT INTO ltqri_slicomments VALUES("617","0","zumba","makeuptutorial@go2.pl","I\'m glad that i see www.joomladdons.eu  again 
<a href=http://www.youtube.com/watch?v=FBL17Kp5p74>zumba dance workout</a>
<a href=http://www.youtube.com/watch?v=FRTryUWp0XM>everyday makeup tutorial</a>
<a href=http://www.youtube.com/watch?v=beX72Js-mdQ>eye makeup</a>
","I&#039;m glad that i see www.joomladdons.eu  again <br />
&lt;a href=http://www.youtube.com/watch?v=FBL17Kp5p74&gt;zumba dance workout&lt;/a&gt;<br />
&lt;a href=http://www.youtube.com/watch?v=FRTryUWp0XM&gt;everyday makeup tutorial&lt;/a&gt;<br />
&lt;a href=http://www.youtube.com/watch?v=beX72Js-mdQ&gt;eye makeup&lt;/a&gt;<br />
","2012-11-17 04:13:56","26","0","-1");
INSERT INTO ltqri_slicomments VALUES("618","0","Rifai","emmerich.kamper@aon.at","Thanks on creating one of the most stylsih blogs I have come across in a long time! It’s truly incredible how much you are able to take away from some thing simply because of how aesthetically gorgeous it is. Youve created a fantastic be site fantastic graphics , structure. site!","Thanks on creating one of the most stylsih blogs I have come across in a long time! It&rsquo;s truly incredible how much you are able to take away from some thing simply because of how aesthetically gorgeous it is. Youve created a fantastic be site fantastic graphics , structure. site!","2012-11-17 09:27:54","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("619","0","Rifai","emmerich.kamper@aon.at","Thanks on creating one of the most stylsih blogs I have come across in a long time! It’s truly incredible how much you are able to take away from some thing simply because of how aesthetically gorgeous it is. Youve created a fantastic be site fantastic graphics , structure. site!","Thanks on creating one of the most stylsih blogs I have come across in a long time! It&rsquo;s truly incredible how much you are able to take away from some thing simply because of how aesthetically gorgeous it is. Youve created a fantastic be site fantastic graphics , structure. site!","2012-11-17 09:27:54","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("459","0","Evelyn Jeanne Shaw","dithmott@aol.com","Hehe I see that you are doing good buddy, lot’s of good articles. It would be good for you if you could invest in some ads you know, your Google rankings would be better probably. If your budget is tight, try to find other blog owners in similar niches and exchange links. Your blog looks like something that can do it big, it would be a shame if the people don’t see it ;) Have a nice day","Hehe I see that you are doing good buddy, lot&rsquo;s of good articles. It would be good for you if you could invest in some ads you know, your Google rankings would be better probably. If your budget is tight, try to find other blog owners in similar niches and exchange links. Your blog looks like something that can do it big, it would be a shame if the people don&rsquo;t see it ;) Have a nice day","2012-10-14 08:15:11","26","0","1");
INSERT INTO ltqri_slicomments VALUES("620","0","Rifai","emmerich.kamper@aon.at","Thanks on creating one of the most stylsih blogs I have come across in a long time! It’s truly incredible how much you are able to take away from some thing simply because of how aesthetically gorgeous it is. Youve created a fantastic be site fantastic graphics , structure. site!","Thanks on creating one of the most stylsih blogs I have come across in a long time! It&rsquo;s truly incredible how much you are able to take away from some thing simply because of how aesthetically gorgeous it is. Youve created a fantastic be site fantastic graphics , structure. site!","2012-11-17 09:27:55","35","0","-1");
INSERT INTO ltqri_slicomments VALUES("621","0","Barbie","xiaorui88@126.com","I cannot tell a lie, that relaly helped.","I cannot tell a lie, that relaly helped.","2012-11-17 10:06:03","25","0","-1");
INSERT INTO ltqri_slicomments VALUES("474","0","Rasim","meskon@meskon.com.pl","Noni Hi there, i read your blog occasionally and i own a silimar one and i was just curious if you get a lot of spam remarks? If so how do you reduce it, any plugin or anything you can recommend? I get so much lately it\'s driving me insane so any help is v ","Noni Hi there, i read your blog occasionally and i own a silimar one and i was just curious if you get a lot of spam remarks? If so how do you reduce it, any plugin or anything you can recommend? I get so much lately it&#039;s driving me insane so any help is v ","2012-10-15 07:42:09","8","0","1");



